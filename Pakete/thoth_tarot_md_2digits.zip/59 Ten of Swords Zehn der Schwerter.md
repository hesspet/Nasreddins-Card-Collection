# Ten of Swords / Zehn der Schwerter

## Positiv / Aufrecht

- Abschluss, Zusammenbruch, Erneuerung möglich

## Schattenseite / Umgekehrt

- Zerstörung, tiefer Fall

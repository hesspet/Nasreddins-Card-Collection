# The Tower / Der Turm

## Positiv / Aufrecht

- Zusammenbruch, Befreiung, plötzliche Erkenntnis

## Schattenseite / Umgekehrt

- Zerstörung, Schock, Trauma

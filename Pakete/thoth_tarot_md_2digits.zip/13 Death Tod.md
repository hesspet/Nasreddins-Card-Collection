# Death / Tod

## Positiv / Aufrecht

- Transformation, Neubeginn, Loslassen

## Schattenseite / Umgekehrt

- Angst, Verdrängung, Weigerung zur Veränderung

# Queen of Swords / Königin der Schwerter

## Positiv / Aufrecht

- Scharfsinn, Unabhängigkeit, Wahrheit

## Schattenseite / Umgekehrt

- Härte, Isolation

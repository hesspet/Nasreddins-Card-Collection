# Ten of Cups / Zehn der Kelche

## Positiv / Aufrecht

- Harmonie, Fülle, Liebe, Ganzheit

## Schattenseite / Umgekehrt

- Überdruss, Zerfall

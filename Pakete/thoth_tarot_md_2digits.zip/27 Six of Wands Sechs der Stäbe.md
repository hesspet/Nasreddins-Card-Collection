# Six of Wands / Sechs der Stäbe

## Positiv / Aufrecht

- Triumph, Erfolg, Führung

## Schattenseite / Umgekehrt

- Hochmut, Scheinerfolg

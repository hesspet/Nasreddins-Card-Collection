# Ace of Wands / As der Stäbe

## Positiv / Aufrecht

- Inspiration, Energie, Wille, Beginn

## Schattenseite / Umgekehrt

- Unruhe, Impulsivität

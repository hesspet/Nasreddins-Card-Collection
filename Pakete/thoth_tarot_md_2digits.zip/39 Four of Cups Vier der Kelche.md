# Four of Cups / Vier der Kelche

## Positiv / Aufrecht

- Zufriedenheit, Komfort

## Schattenseite / Umgekehrt

- Trägheit, Langeweile

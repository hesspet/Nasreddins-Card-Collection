# Three of Wands / Drei der Stäbe

## Positiv / Aufrecht

- Vision, Kooperation, Umsetzung

## Schattenseite / Umgekehrt

- Planlosigkeit, Unsicherheit

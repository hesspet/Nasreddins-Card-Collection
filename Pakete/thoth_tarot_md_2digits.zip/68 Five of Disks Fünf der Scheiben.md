# Five of Disks / Fünf der Scheiben

## Positiv / Aufrecht

- Herausforderung, Mangel, Sorge

## Schattenseite / Umgekehrt

- Existenzangst, Armutsbewusstsein

# The Priestess / Die Hohepriesterin

## Positiv / Aufrecht

- Intuition, inneres Wissen, Stille, Mysterium

## Schattenseite / Umgekehrt

- Geheimhaltung, Täuschung, Verdrängung

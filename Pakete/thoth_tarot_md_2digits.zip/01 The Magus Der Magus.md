# The Magus / Der Magus

## Positiv / Aufrecht

- Manifestation, Wille, Sprache, Bewusstsein

## Schattenseite / Umgekehrt

- Täuschung, Manipulation, Ego-Spiel

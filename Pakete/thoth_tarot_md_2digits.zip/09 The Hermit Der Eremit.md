# The Hermit / Der Eremit

## Positiv / Aufrecht

- Rückzug, Weisheit, inneres Licht

## Schattenseite / Umgekehrt

- Isolation, Einsamkeit, Blindheit

# Knight of Wands / Ritter der Stäbe

## Positiv / Aufrecht

- Dynamik, Abenteuer, Führungskraft

## Schattenseite / Umgekehrt

- Rücksichtslosigkeit, Übermut

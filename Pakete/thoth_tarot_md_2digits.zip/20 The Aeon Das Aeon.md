# The Aeon / Das Aeon

## Positiv / Aufrecht

- Erwachen, neues Bewusstsein, Evolution

## Schattenseite / Umgekehrt

- Ablehnung des Wandels

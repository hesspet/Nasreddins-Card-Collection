# Queen of Cups / Königin der Kelche

## Positiv / Aufrecht

- Empathie, Intuition, Liebe

## Schattenseite / Umgekehrt

- Selbstaufgabe, Überempfindlichkeit

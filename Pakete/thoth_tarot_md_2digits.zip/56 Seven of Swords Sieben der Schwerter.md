# Seven of Swords / Sieben der Schwerter

## Positiv / Aufrecht

- List, Strategie, Vorsicht

## Schattenseite / Umgekehrt

- Betrug, Selbsttäuschung

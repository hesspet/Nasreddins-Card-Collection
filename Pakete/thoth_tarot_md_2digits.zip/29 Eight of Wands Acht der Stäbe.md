# Eight of Wands / Acht der Stäbe

## Positiv / Aufrecht

- Tempo, Kommunikation, Dynamik

## Schattenseite / Umgekehrt

- Überhastung, Chaos

# Prince of Disks / Prinz der Scheiben

## Positiv / Aufrecht

- Planung, Fleiß, Pragmatismus

## Schattenseite / Umgekehrt

- Langsamkeit, Starrheit

# Fortune / Glück

## Positiv / Aufrecht

- Schicksal, Wandel, Glück, Kreisläufe

## Schattenseite / Umgekehrt

- Chaos, Unvorhersehbarkeit

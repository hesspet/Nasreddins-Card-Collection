# Eight of Disks / Acht der Scheiben

## Positiv / Aufrecht

- Geduld, Fleiß, Planung

## Schattenseite / Umgekehrt

- Perfektionismus, Trägheit

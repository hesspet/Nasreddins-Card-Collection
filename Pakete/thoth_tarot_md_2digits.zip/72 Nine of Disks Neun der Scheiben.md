# Nine of Disks / Neun der Scheiben

## Positiv / Aufrecht

- Materieller Erfolg, Selbstwert

## Schattenseite / Umgekehrt

- Gier, Egoismus

# Five of Wands / Fünf der Stäbe

## Positiv / Aufrecht

- Konflikt, Spannung, Wettbewerb

## Schattenseite / Umgekehrt

- Chaos, Überforderung

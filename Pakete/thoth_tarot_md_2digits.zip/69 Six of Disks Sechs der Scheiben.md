# Six of Disks / Sechs der Scheiben

## Positiv / Aufrecht

- Wohlstand, Ausgleich, Großzügigkeit

## Schattenseite / Umgekehrt

- Egoismus, Ungleichgewicht

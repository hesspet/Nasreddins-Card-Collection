# Princess of Disks / Prinzessin der Scheiben

## Positiv / Aufrecht

- Neubeginn, Wachstum, Erdung

## Schattenseite / Umgekehrt

- Unsicherheit, Passivität

# Queen of Wands / Königin der Stäbe

## Positiv / Aufrecht

- Charisma, Leidenschaft, Selbstvertrauen

## Schattenseite / Umgekehrt

- Manipulation, Dominanz

# The Emperor / Der Kaiser

## Positiv / Aufrecht

- Struktur, Autorität, Ordnung, Stabilität

## Schattenseite / Umgekehrt

- Starrheit, Machtmissbrauch

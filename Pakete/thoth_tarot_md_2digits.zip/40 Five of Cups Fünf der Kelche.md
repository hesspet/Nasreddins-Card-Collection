# Five of Cups / Fünf der Kelche

## Positiv / Aufrecht

- Trauer, Verlust, Enttäuschung

## Schattenseite / Umgekehrt

- Bitterkeit, Festhalten am Alten

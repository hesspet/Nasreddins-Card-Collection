# The Moon / Der Mond

## Positiv / Aufrecht

- Traum, Intuition, Schatten, Zyklen

## Schattenseite / Umgekehrt

- Täuschung, Angst, Unklarheit

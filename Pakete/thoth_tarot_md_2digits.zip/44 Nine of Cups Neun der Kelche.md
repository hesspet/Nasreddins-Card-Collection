# Nine of Cups / Neun der Kelche

## Positiv / Aufrecht

- Erfüllung, Zufriedenheit, Reichtum

## Schattenseite / Umgekehrt

- Selbstzufriedenheit, Bequemlichkeit

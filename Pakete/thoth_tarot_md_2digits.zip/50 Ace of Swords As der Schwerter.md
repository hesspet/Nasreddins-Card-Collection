# Ace of Swords / As der Schwerter

## Positiv / Aufrecht

- Klarheit, Wahrheit, Erkenntnis

## Schattenseite / Umgekehrt

- Härte, Aggression

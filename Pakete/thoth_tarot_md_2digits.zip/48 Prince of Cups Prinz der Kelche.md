# Prince of Cups / Prinz der Kelche

## Positiv / Aufrecht

- Kreativität, Idealismus

## Schattenseite / Umgekehrt

- Unzuverlässigkeit, Illusion

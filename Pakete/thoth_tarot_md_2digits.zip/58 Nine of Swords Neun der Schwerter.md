# Nine of Swords / Neun der Schwerter

## Positiv / Aufrecht

- Angst, mentale Qualen

## Schattenseite / Umgekehrt

- Depression, Verzweiflung

# Seven of Disks / Sieben der Scheiben

## Positiv / Aufrecht

- Zweifel, Rückschlag, Zögern

## Schattenseite / Umgekehrt

- Stagnation, Resignation

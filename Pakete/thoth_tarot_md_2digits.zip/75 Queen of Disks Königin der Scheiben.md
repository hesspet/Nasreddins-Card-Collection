# Queen of Disks / Königin der Scheiben

## Positiv / Aufrecht

- Fürsorge, Sicherheit, Fülle

## Schattenseite / Umgekehrt

- Besitzergreifen, Bequemlichkeit

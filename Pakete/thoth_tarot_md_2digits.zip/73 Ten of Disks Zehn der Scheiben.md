# Ten of Disks / Zehn der Scheiben

## Positiv / Aufrecht

- Fülle, Stabilität, Erfüllung

## Schattenseite / Umgekehrt

- Abhängigkeit, Materialismus

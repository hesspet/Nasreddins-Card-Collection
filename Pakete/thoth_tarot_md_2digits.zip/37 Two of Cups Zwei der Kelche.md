# Two of Cups / Zwei der Kelche

## Positiv / Aufrecht

- Beziehung, Harmonie, Einheit

## Schattenseite / Umgekehrt

- Abhängigkeit, Verstrickung

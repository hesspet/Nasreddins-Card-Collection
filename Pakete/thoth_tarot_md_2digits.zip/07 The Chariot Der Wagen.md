# The Chariot / Der Wagen

## Positiv / Aufrecht

- Kontrolle, Wille, Sieg, Vorwärtsbewegung

## Schattenseite / Umgekehrt

- Überforderung, Kontrollverlust

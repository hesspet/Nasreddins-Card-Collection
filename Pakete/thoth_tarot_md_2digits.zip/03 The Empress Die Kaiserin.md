# The Empress / Die Kaiserin

## Positiv / Aufrecht

- Fruchtbarkeit, Wachstum, Liebe, Kreativität

## Schattenseite / Umgekehrt

- Überfluss, Besitzgier, Abhängigkeit

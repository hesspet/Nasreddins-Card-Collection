# Ace of Cups / As der Kelche

## Positiv / Aufrecht

- Liebe, Öffnung, Gefühle

## Schattenseite / Umgekehrt

- Sentimentalität, Illusion

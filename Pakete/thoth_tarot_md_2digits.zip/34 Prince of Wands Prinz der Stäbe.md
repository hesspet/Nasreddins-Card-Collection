# Prince of Wands / Prinz der Stäbe

## Positiv / Aufrecht

- Energie, jugendlicher Antrieb

## Schattenseite / Umgekehrt

- Ungestümheit, Unbeständigkeit

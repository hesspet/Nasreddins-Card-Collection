# Princess of Cups / Prinzessin der Kelche

## Positiv / Aufrecht

- Offenheit, emotionale Reinheit

## Schattenseite / Umgekehrt

- Naivität, Verletzlichkeit

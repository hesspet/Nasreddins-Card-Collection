# Five of Swords / Fünf der Schwerter

## Positiv / Aufrecht

- Lektion, Akzeptanz, Ende

## Schattenseite / Umgekehrt

- Niederlage, Selbstzweifel

# Four of Wands / Vier der Stäbe

## Positiv / Aufrecht

- Erfolg, Stabilität, Feier

## Schattenseite / Umgekehrt

- Übermut, Stagnation

# Lust / Lust

## Positiv / Aufrecht

- Leidenschaft, Lebensfreude, Kraft

## Schattenseite / Umgekehrt

- Ausschweifung, Maßlosigkeit

# Knight of Disks / Ritter der Scheiben

## Positiv / Aufrecht

- Ausdauer, Verlässlichkeit, Sicherheit

## Schattenseite / Umgekehrt

- Sturheit, Trägheit

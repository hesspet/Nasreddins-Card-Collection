# Knight of Swords / Ritter der Schwerter

## Positiv / Aufrecht

- Schnelligkeit, Intellekt, Analyse

## Schattenseite / Umgekehrt

- Aggression, Impulsivität

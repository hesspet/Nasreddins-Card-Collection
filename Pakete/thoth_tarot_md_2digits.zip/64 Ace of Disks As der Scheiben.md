# Ace of Disks / As der Scheiben

## Positiv / Aufrecht

- Materielle Fülle, Manifestation, Potenzial

## Schattenseite / Umgekehrt

- Gier, Blockaden

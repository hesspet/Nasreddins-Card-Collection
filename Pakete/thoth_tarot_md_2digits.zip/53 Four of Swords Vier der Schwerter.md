# Four of Swords / Vier der Schwerter

## Positiv / Aufrecht

- Ruhe, Heilung, Pause

## Schattenseite / Umgekehrt

- Stillstand, Verdrängung

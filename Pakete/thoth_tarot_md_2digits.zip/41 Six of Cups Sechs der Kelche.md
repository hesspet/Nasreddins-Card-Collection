# Six of Cups / Sechs der Kelche

## Positiv / Aufrecht

- Genuss, Leichtigkeit, Sinnlichkeit

## Schattenseite / Umgekehrt

- Zerstreuung, Oberflächlichkeit

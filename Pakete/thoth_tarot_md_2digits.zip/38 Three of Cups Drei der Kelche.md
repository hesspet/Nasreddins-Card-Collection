# Three of Cups / Drei der Kelche

## Positiv / Aufrecht

- Freude, Fülle, Kreativität

## Schattenseite / Umgekehrt

- Übermaß, Oberflächlichkeit

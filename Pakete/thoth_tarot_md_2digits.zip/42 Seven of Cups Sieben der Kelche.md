# Seven of Cups / Sieben der Kelche

## Positiv / Aufrecht

- Verführung, Fantasie, Illusion

## Schattenseite / Umgekehrt

- Selbsttäuschung, Sucht

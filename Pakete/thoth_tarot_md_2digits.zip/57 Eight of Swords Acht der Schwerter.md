# Eight of Swords / Acht der Schwerter

## Positiv / Aufrecht

- Einschränkung, Hindernisse

## Schattenseite / Umgekehrt

- Gefangenheit, Blockade

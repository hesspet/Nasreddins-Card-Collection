# Six of Swords / Sechs der Schwerter

## Positiv / Aufrecht

- Objektivität, Analyse, Erfolg

## Schattenseite / Umgekehrt

- Kälte, Überintellektualisierung

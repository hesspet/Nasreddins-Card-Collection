# Princess of Wands / Prinzessin der Stäbe

## Positiv / Aufrecht

- Inspiration, Aufbruch, Mut

## Schattenseite / Umgekehrt

- Unreife, Naivität

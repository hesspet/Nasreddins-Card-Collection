# The Hierophant / Der Hierophant

## Positiv / Aufrecht

- Tradition, Lehre, Initiation, spirituelle Ordnung

## Schattenseite / Umgekehrt

- Dogma, Autoritätsgläubigkeit, Unfreiheit

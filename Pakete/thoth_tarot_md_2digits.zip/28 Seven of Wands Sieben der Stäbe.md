# Seven of Wands / Sieben der Stäbe

## Positiv / Aufrecht

- Mut, Durchhalten, Standhaftigkeit

## Schattenseite / Umgekehrt

- Überforderung, Widerstand

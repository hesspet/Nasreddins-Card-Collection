# Ten of Wands / Zehn der Stäbe

## Positiv / Aufrecht

- Belastung, Verantwortung, Pflicht

## Schattenseite / Umgekehrt

- Erdrückung, Burnout

# Three of Disks / Drei der Scheiben

## Positiv / Aufrecht

- Aufbau, Kooperation, Ergebnis

## Schattenseite / Umgekehrt

- Mühsamkeit, Blockade

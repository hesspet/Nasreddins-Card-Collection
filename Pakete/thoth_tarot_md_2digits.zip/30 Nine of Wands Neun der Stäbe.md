# Nine of Wands / Neun der Stäbe

## Positiv / Aufrecht

- Ausdauer, Kraft, Selbstbehauptung

## Schattenseite / Umgekehrt

- Erschöpfung, Druck

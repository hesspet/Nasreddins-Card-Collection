# Eight of Cups / Acht der Kelche

## Positiv / Aufrecht

- Loslassen, Übergang, Reife

## Schattenseite / Umgekehrt

- Apathie, Erstarrung

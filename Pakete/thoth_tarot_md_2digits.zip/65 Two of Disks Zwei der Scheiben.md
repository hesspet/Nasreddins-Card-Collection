# Two of Disks / Zwei der Scheiben

## Positiv / Aufrecht

- Wandel, Ausgleich, Dynamik

## Schattenseite / Umgekehrt

- Instabilität, Unruhe

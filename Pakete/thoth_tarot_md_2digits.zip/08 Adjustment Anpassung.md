# Adjustment / Anpassung

## Positiv / Aufrecht

- Ausgleich, Wahrheit, Karma, Balance

## Schattenseite / Umgekehrt

- Ungerechtigkeit, Verzerrung

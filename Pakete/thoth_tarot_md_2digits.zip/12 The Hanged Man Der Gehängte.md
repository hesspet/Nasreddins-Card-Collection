# The Hanged Man / Der Gehängte

## Positiv / Aufrecht

- Opfer, Hingabe, Perspektivwechsel

## Schattenseite / Umgekehrt

- Stagnation, Opferrolle

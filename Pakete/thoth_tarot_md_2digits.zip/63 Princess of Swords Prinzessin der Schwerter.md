# Princess of Swords / Prinzessin der Schwerter

## Positiv / Aufrecht

- Wachsamkeit, Mut, Intuition

## Schattenseite / Umgekehrt

- Misstrauen, Unruhe

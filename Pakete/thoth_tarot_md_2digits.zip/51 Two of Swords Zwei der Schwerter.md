# Two of Swords / Zwei der Schwerter

## Positiv / Aufrecht

- Ruhe, Balance, Harmonie

## Schattenseite / Umgekehrt

- Blockade, Leugnung

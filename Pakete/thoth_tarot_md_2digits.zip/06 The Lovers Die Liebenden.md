# The Lovers / Die Liebenden

## Positiv / Aufrecht

- Vereinigung, Entscheidung, Polarität, Liebe

## Schattenseite / Umgekehrt

- Zerrissenheit, Abhängigkeit, Konflikt

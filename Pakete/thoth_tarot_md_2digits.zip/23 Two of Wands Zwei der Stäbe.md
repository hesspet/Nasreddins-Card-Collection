# Two of Wands / Zwei der Stäbe

## Positiv / Aufrecht

- Entscheidung, Macht, Ziel

## Schattenseite / Umgekehrt

- Dominanz, Aggression

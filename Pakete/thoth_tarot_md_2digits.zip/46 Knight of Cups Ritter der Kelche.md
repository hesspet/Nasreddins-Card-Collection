# Knight of Cups / Ritter der Kelche

## Positiv / Aufrecht

- Charme, Romantik, Vision

## Schattenseite / Umgekehrt

- Flucht, Realitätsverlust

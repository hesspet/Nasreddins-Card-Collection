# Prince of Swords / Prinz der Schwerter

## Positiv / Aufrecht

- Neugier, Analyse, Ideen

## Schattenseite / Umgekehrt

- Zersplitterung, Instabilität

# Four of Disks / Vier der Scheiben

## Positiv / Aufrecht

- Sicherheit, Stabilität, Einfluss

## Schattenseite / Umgekehrt

- Starrheit, Besitzdenken

S12_Swords12.jpg

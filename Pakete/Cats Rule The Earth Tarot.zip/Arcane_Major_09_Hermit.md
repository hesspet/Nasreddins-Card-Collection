**DER EREMIT/THE HERMIT**

* Klugheit, insbesondere Verrat, Verstellung, Korruption, Schurkerei.
* **Umgekehrt:** Verheimlichung, Verkleidung, Politik, Angst, 
  unbegründete Vorsicht.

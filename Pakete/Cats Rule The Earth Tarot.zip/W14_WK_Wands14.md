**K�NIG DER ST�BE**

Eine dunkle, leidenschaftliche, lebhafte, energische und edle Pers�nlichkeit. Der K�nig h�lt einen bl�henden Stab und tr�gt eine symbolische Krone. Auf seinem Thron ist ein L�we dargestellt.

* Dunkler Mann, freundlich, ehrbar, verheiratet, ehrlich und gewissenhaft. 
* **Umgekehrt:** Gut, aber streng; ernst, jedoch tolerant. 

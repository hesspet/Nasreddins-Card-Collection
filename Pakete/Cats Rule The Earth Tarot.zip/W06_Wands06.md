**SECHS DER STÄBE**

Ein berittener Mann trägt einen mit Lorbeer geschmückten Stab. Fußsoldaten mit Stäben flankieren ihn.

* Triumph, gute Nachrichten, Erfüllung von Hoffnungen. 
* **Umgekehrt:** Furcht, Verrat, Illoyalität. 

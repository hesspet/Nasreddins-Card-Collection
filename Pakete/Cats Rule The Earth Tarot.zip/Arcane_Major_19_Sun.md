**DIE SONNE/THE SUN**

* Materielles Glück, glückliche Ehe, Zufriedenheit.
* **Umgekehrt:** Dasselbe in geringerem Ausmaß.

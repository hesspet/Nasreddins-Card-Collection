S05_Swords05.jpg

C09_Cups09.jpg

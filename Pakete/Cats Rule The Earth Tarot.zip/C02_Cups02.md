C02_Cups02.jpg

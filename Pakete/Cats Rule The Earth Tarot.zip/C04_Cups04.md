C04_Cups04.jpg

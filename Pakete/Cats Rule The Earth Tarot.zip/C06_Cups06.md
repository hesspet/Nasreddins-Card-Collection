C06_Cups06.jpg

C03_Cups03.jpg

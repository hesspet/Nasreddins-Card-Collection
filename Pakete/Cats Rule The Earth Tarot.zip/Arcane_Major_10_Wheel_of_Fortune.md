**DAS RAD DES SCHICKSALS/ WHEEL OF FORTUNE**

* Schicksal, Glück, Erfolg, Wohlstand.
* **Umgekehrt:** Zunahme, Überfluss, Überflüssigkeit.

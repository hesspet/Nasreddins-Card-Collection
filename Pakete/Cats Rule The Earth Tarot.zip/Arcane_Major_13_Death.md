**DER TOD/DEATH**

* Ende, Sterblichkeit, Zerstörung, Verfall.
* **Umgekehrt:** Trägheit, Schlaf, Lethargie, Versteinerung, Schlafwandeln.

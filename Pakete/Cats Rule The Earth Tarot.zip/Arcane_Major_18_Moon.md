**DER MOND/THE MOON**

*  Verborgene Feinde, Gefahr, Verleumdung, Dunkelheit, Schrecken, Täuschung, Irrtum. 
* **Umgekehrt:** Instabilität, Wankelmut, Stille, geringere Grade von 
  Täuschung und Irrtum.

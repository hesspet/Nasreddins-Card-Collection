**ZWEI DER STÄBE**

Ein Mann auf einer Zinne hält einen Globus in der rechten und einen Stab in der linken Hand.

* Reichtum, aber auch Traurigkeit, Krankheit, Unzufriedenheit. 
* **Umgekehrt:** Überraschung, Verwunderung, Emotionen, Ärger. 

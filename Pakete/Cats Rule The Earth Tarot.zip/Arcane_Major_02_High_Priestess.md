**DIE HOHEPRIESTERIN/THE HIGH PRIESTESS**

* Geheimnisse, Mysterien, die Zukunft, die noch unenthüllt ist; die Frau, die den Fragenden interessiert (wenn männlich); der Fragende selbst (wenn weiblich), Schweigen, Beharrlichkeit, Weisheit, Wissenschaft.

* **Umgekehrt:** Leidenschaft, moralischer oder körperlicher Eifer, Selbstüberschätzung, oberflächliches Wissen.

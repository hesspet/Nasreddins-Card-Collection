S04_Swords04.jpg

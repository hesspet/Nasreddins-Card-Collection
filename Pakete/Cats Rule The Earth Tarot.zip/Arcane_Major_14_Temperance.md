**DIE MÄSSIGUNG/TEMPERANCE**

* Sparsamkeit, Mäßigung, Wirtschaftlichkeit, Anpassung.
* **Umgekehrt:** Dinge im Zusammenhang mit Kirchen, Religionen, Sekten, dem Priestertum, auch unglückliche Kombinationen, Uneinigkeit, konkurrierende Interessen.

S13_Swords13.jpg

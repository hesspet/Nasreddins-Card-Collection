**RITTER DER STÄBE**

Er wird auf einer Reise dargestellt, bewaffnet mit einem kurzen Stab. Er reitet an Hügeln oder Pyramiden vorbei, ist aber nicht kriegerisch unterwegs.

* Abreise, Abwesenheit, Flucht, Emigration. Ein dunkler, freundlicher junger Mann. Ortswechsel. 
* **Umgekehrt:** Bruch, Trennung, Unterbrechung, Zwietracht. 

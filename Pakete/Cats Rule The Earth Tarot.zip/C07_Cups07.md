C07_Cups07.jpg

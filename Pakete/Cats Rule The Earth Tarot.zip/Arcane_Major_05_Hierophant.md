**DER HIEROPHANT/THE HIEROPHANT**

* Ehe, Bündnis, Gefangenschaft, Dienstbarkeit, Barmherzigkeit und Güte, Inspiration, der Mann, an den sich der Fragende wendet. 
* **Umgekehrt:** Gesellschaft, gutes Einvernehmen, Eintracht, übermäßige Freundlichkeit, Schwäche.

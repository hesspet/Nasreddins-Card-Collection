**NEUN DER STÄBE**

Eine Figur lehnt sich auf einen Stab und wirkt erwartungsvoll einen Feind erwartet. Acht weitere Stäbe stehen wie eine Palisade ihm.

* Stärke im Widerstand Aussetzung. 
* **Umgekehrt:** Hindernisse, Widrigkeiten, Unglück. 

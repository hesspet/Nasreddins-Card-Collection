**DIE WELT** 

* Sicherer Erfolg, Route, Reise, Auswanderung, Flucht, Ortswechsel.
* **Umgekehrt:** Trägheit, Starrheit, Stillstand, Beständigkeit.

**DAS JÜNGSTE GERICHT/ THE LAST JUDGMENT**

*  Veränderung der Position, Erneuerung, Ergebnis.
* **Umgekehrt:** Schwäche, Kleinmut, Einfachheit, auch Überlegung, Entscheidung, Urteil.

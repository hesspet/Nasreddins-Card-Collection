S08_Swords08.jpg

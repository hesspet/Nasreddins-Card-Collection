**DER NARR/THE FOOL** 

* Torheit, Wahnsinn, Verschwendung, Rausch, Delirium, Raserei, Betrug.
* **Umgekehrt:** Nachlässigkeit, Abwesenheit, Verteilung, Sorglosigkeit, Apathie, Nichtigkeit, Eitelkeit.
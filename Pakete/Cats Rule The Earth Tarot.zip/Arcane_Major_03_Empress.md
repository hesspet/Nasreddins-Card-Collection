**DIE KAISERIN/THE EMPRESS**

* Fruchtbarkeit, Initiative, Tatkraft, lange Tage, Heimlichkeit, das Unbekannte, 
  Schwierigkeiten, Zweifel, Unwissenheit.
* **Umgekehrt:** Licht, Wahrheit, die Entwirrung komplizierter Angelegenheiten, öffentliche Freude, nach anderer Lesart auch Schwanken.

**DER WAGEN/THE CHARIOT**

* Hilfe, Vorsehung, auch Krieg, Triumph, Anmaßung, Rache, Schwierigkeiten.
* **Umgekehrt:** Aufruhr, Streit, Auseinandersetzung, Rechtsstreit, 
  Niederlage.

**KÖNIGIN DER STÄBE**

Die Königin teilt die Eigenschaften des Königs, ist jedoch emotional magnetischer. Die Stäbe sind stets blühend und repräsentieren Leben und Lebendigkeit.

* Dunkle Frau, freundlich, keusch, liebevoll, ehrenhaft. Bei einer benachbarten Männerkarte ist sie 
  diesem wohlgesinnt; bei einer Frauenkarte interessiert sie sich für den Fragenden. Auch Liebe zu Geld. 
* **Umgekehrt:** Gut, sparsam, hilfreich, dienstbar. Bedeutet auch Eifersucht, Täuschung und Untreue. 

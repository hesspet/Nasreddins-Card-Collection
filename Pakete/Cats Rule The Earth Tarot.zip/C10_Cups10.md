C10_Cups10.jpg

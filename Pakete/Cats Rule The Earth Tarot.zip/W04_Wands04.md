**VIER DER STÄBE**

Vier Stäbe tragen eine Girlande. Zwei Frauen mit Blumen stehen neben einer Brücke, die zu einem Herrenhaus führt.

* Ländliches Leben, Harmonie, Wohlstand, Frieden. 
* **Umgekehrt:** Dieselbe Bedeutung bleibt bestehen. 

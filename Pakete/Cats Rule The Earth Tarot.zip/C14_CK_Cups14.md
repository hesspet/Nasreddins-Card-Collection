C14_Cups14.jpg

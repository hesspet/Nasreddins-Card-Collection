**DIE LIEBENDEN/THE LOVERS**

* Anziehungskraft, Liebe, Schönheit, überwundene Prüfungen. 
* **Umgekehrt:** Scheitern, törichte Pläne.

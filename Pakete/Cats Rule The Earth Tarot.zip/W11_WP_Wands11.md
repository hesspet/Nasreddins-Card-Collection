**PAGE DER STÄBE**

Ein junger Mann steht wie in einer Verkündigungsszene. Er ist unbekannt, aber treu, und seine Botschaften sind seltsam.

* Wahrsagerische Bedeutung: Dunkler junger Mann, treu, ein Liebhaber, ein Bote. Neben einem Mann spricht er günstig über diesen. Gefährlicher Rivale, wenn der Page der Kelche folgt. 
* **Umgekehrt:** Anekdoten, Ankündigungen, schlechte Nachrichten, Unentschlossenheit und Instabilität. 

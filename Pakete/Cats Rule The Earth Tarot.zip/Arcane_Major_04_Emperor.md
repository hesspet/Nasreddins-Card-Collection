**DER KAISER/THE EMPEROR** 

* Stabilität, Macht, Hilfe, Schutz, eine große Person, Überzeugung, Vernunft. 
* **Umgekehrt:** Wohlwollen, Mitgefühl, Anerkennung, auch Verwirrung der Feinde, Hindernis, Unreife.

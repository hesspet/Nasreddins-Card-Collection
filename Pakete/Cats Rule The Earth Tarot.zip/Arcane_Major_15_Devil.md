**DER TEUFEL/THE DEVIL**

* Verwüstung, Gewalt, Kraft, Heftigkeit, außergewöhnliche Anstrengungen, Schicksal, das vorbestimmt ist, aber nicht notwendigerweise böse.
* **Umgekehrt:** Böses Schicksal, Schwäche, Kleinlichkeit, Blindheit.

S09_Swords09.jpg

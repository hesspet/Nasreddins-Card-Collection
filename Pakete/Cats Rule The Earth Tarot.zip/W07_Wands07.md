**SIEBEN DER STÄBE**

Ein junger Mann steht auf einem felsigen Vorsprung und wehrt sechs Stäbe ab, die von unten erhoben werden.

* Tapferkeit, Diskussion, Konkurrenz, Erfolg trotz widriger Umstände. 
* **Umgekehrt:** Verwirrung, Peinlichkeiten, Angst. 

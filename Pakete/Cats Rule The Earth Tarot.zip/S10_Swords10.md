S10_Swords10.jpg

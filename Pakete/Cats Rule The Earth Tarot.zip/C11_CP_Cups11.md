C11_Cups11.jpg

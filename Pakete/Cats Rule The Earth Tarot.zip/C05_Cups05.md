C05_Cups05.jpg

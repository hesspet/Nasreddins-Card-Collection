P02_Pents02.jpg

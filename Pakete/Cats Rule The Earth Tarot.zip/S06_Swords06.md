S06_Swords06.jpg

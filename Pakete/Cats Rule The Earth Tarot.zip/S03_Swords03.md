S03_Swords03.jpg

C01_Cups01.jpg

**FÜNF DER STÄBE**

Jugendliche schwingen Stäbe, als ob sie spielen oder kämpfen.

* Nachahmung, Konkurrenz, Anstrengung, Reichtumssuche. 
* **Umgekehrt:** Täuschung, Widerspruch, Streitigkeiten. 

S07_Swords07.jpg

**ASS DER STÄBE**

Eine Hand erscheint aus einer Wolke und hält einen Stab.

* Schöpfung, Unternehmungsgeist, Anfang, Geburt, Wohlstand. 
* **Umgekehrt:** Verfall, Ruin, getrübte Freude. 

**DER TURM/THE TOWER**

* Elend, Not, Ruin, Armut, Widrigkeiten, Unglück, Schande, Täuschung.
* **Umgekehrt:** Laut einer Lesart dasselbe in geringerem Maße, auch Unterdrückung, Gefangenschaft, Tyrannei.

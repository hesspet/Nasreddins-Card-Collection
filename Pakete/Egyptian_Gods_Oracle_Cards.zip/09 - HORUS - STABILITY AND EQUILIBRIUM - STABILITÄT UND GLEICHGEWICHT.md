# 9 Horus • Stabilität und Gleichgewicht

Er wird als Falke oder falkenköpfiger Mann dargestellt. Sein Name bedeutet „der Ferne“: der Falke, der majestätisch durch den Himmel gleitet. Während eines Kampfes mit dem Gott Seth verlor Horus sein linkes Auge, das dann vom Gott Thot geheilt wurde. Dieses Auge wurde „Auge des Horus“ genannt. Horus verkörpert universelle Ordnung und Harmonie. Vertraue dem Gott Horus, denn alles wird gut ausgehen – auch wenn Du den schmerzhaften Verlust falscher Freunde erlebst. Auf der physischen Ebene wirst Du in Harmonie gehüllt sein. Seine Gegenwart rät Dir, mit größerer Achtsamkeit auf Dein Leben zu achten. Er hilft Dir, alles von einem niederen auf ein höheres Niveau zu transformieren.

# 9 Horus • Stability and Equilibrium

He  is  represented  as  a  hawk  or  a  hawk-headed  man. His  name  means  “the  distant one”: the  falcon,  with  its majestic soaring and swooping in  the sky. During a con-frontation  with  the  god  Seth,  Horus  lost  his  left  eye, which  was  then  healed  by  the  god  Thot.  The  eye  was given  the  name  of  the  “Eye  of  Horus”.  He  embodies universal order and  harmony. Put  your  trust in  the  god Horus, because everything will turn out fine, as with the albeit painful loss of  false friends. On the physical plane, you will  be  wrapped  in  harmony.  His  presence  advises you  to show  more  awareness  in  the  way you  pay atten-tion  to  your  life.  He  helps  you  to  transform  all  things from  an  inferior to superior level.

------


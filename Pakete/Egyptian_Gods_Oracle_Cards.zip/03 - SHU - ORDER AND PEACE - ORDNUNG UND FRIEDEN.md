# 3 Shu • Ordnung und Frieden

Urgott, Sohn von Amun-Ra, der die Luft und den Wind personifiziert, aber auch das Licht, das die urzeitliche Finsternis durchbrach. Sein Name bedeutet „Der, der aufsteigt“. Shu wird üblicherweise mit einer Straußenfeder auf dem Kopf dargestellt. Die Straußenfeder ist ein Symbol für Leichtigkeit und Reinheit: die Luft als Atem des Lebens und kühlende Brise. Diese Karte rät Dir, eine diszipliniertere Art des Verhaltens anzunehmen. Versuche, unkontrollierte Impulse von Begierden und Leidenschaften zu vermeiden. Es ist Zeit, Dein Leben zu erleichtern und wieder ins Gleichgewicht zu bringen. Beachte Regeln mit größerer Verantwortung.

# 3 Shu  • Order and  Peace

Primordial  God, son  of Amon-Ra, who  personifies the air,  the  wind  but  also the  light  that  broke the  primordial darkness.  His  name  means “He who rises”. Shu  is commonly portrayed with an ostrich feather on his head. The ostrich  feather  is a symbol of lightness and  purity: the air  meaning breath  of life and  cooling breeze. This card  advises  you  to  adopt  a  more  disciplined  form  of behaviour. Try to avoid uncontrolled impulses of  desires and  passions. The  time  has come to lighten  and  re-bal-ance your life. Respect rules with greater responsibility.

------


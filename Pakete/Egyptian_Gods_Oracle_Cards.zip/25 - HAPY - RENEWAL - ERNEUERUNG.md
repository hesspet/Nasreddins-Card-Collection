# 25 Hapy • Erneuerung

Er steht für das fließende, turbulente Element. Hapy symbolisiert die Fruchtbarkeit des Landes, die Fülle der Ernten und das durch die jährliche Nilflut erneuerte Leben. Diese bringt Tiere und Pflanzen hervor: „Der Herr der Fische, Vögel und Sümpfe“. Er wird als Mann mit großem Bauch und weiblichen Brüsten dargestellt — Zeichen der Fruchtbarkeit. Folge dem göttlichen Licht in Richtung Deiner Leidenschaften. Jetzt ist die Zeit, das Leben in vollen Zügen zu genießen. Hapy verkündet Erneuerung, ein neues Leben und neue Wege. Auch materieller Wohlstand, insbesondere im Handel, kann bevorstehen.

# 25 Hapy • Renewal

He  represents  the  liquid  and  turbulent  element.  He symbolises  the  fertility  of  the  land,  the  abundance  of crops and life renewed by the annual flood of  the  River Nile  which  brings fauna  and  vegetation: “The  Lord of fish,  birds  and  swamps”.  Hapy  is  portrayed  as  a  man with  a large belly and  large female  breasts, a symbol of fertility.  Follow the  divine  light  along  the  direction  of passions.  It  is  time  to  fully  experience  everything  the world  has to offer you. Go with  the flow and  live more intensely!  Hapy  heralds  a  renewal,  a  new life and  new paths  to go down. You could acquire  imminent fortune in the field of  trade.

------


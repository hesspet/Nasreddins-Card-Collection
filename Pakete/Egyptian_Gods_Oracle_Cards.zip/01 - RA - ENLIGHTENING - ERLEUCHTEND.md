﻿# 1 Ra • Erleuchtung

Erster Sonnengott, „Der, der emporsteigt, hoch in den Himmel klettert“. Leben und Wohlstand kommen von der Sonne und ihrer Wärme. Sein Symbol ist das Auge des Ra, das auch mit der Bedeutung des „dritten Auges“ verbunden ist. Die Energie des Ra ist vital – die Quelle kreativen Wachstums. Diese Gottheit schenkt Klarheit und Transparenz. Unter dem Einfluss Ras gibt es nichts zu fürchten: Er hilft Dir, Wunden zu heilen und verlorene Harmonie wiederherzustellen – jedoch durch Handeln. Vor allem rät er Dir, die Ausflüchte des Mondes aufzugeben und mutig, im vollen Licht des Tages, zu handeln.

# 1 Ra • Enlightening

First  sun  god, “He  who  rises  up,  climbing  high  in  the sky”.  Life  and  prosperity  come  from  the  Sun  and  its heat. Its symbol is the Eye of  Ra, also associated with the meaning of  the “third eye”. The energy of  Ra is vital, the source  of creative  growth. This  deity  instils clarity  and transparency. There  is  nothing to fear  under  the  influ-ence of  Ra: he helps you to heal wounds and  restore lost harmony,  but  with  action.  Above all,  he  advises you to abandon  the  subterfuges  of the  Moon  and  to act  boldly and  in  the full  light of  day.

------


# 15 Ptah • Geschick und Schaffenskraft

Gott und Schutzpatron der Handwerker, Architekten, des Wissens und Könnens. Er ist Ingenieur, Maurer, Schmied und Künstler. Dargestellt als mumifizierter Mann mit Bart, hält er das Anch-Szepter – Symbol des Lebens – und den Djed-Stab der Macht, Symbol der Stabilität. Ptah schenkt Dir einen Zustand müheloser Konzentration. Er bringt Dir Leichtigkeit und vertrautes Geschick und macht es Dir möglich, alle Arten von Aufgaben mit Leichtigkeit zu bewältigen. Unter seinem Einfluss kannst Du Arbeit in Spiel verwandeln, geistige Fähigkeiten entwickeln, Leidenschaften entfachen und zugleich meistern.

# 15 Ptah  • Skill

God and  patron of  craftsmen and architects as well as of knowledge and  know-how. He  is an  engineer,  bricklay-er, blacksmith and artist. He is depicted as a mummified man with a beard, holding the Ankh sceptre, the symbol of  life, and the Djed staff  of  power, a symbol of  stability. Ptah  provides you with  the state of  effortless concentra-tion.  Bringing you lightness  and  familiar skill,  he  will make it easy for you to perform all manner of  operations. Under his influence and through serene objectivity, you have  the  chance  to  transform  your  work  into  play and develop the  power of mental development,  the ability to transform  things or the capacity to awaken  passions but also to dominate them.

------


# 28 Anubis (Schutz) • Wächter

In dieser Form ist Anubis der Beschützer der Lebenden und Toten. Er bewacht die Pforten zwischen den Welten, schützt vor bösen Geistern und hält das Gleichgewicht zwischen Licht und Schatten. Diese Karte ruft Dich dazu auf, Deine Grenzen zu achten und Schutzräume zu schaffen — innerlich wie äußerlich. Lerne, Deine Energie zu wahren. Wenn Du Dich sicher fühlst, kannst Du kraftvoll wachsen.

# 28 Anubis (Protector) • Guardian

In this form, Anubis is the protector of the living and the dead. He guards the gates between worlds, shields from evil spirits, and maintains the balance between light and shadow. This card calls on you to respect your boundaries and create spaces of protection — both internally and externally. Learn to conserve your energy. When you feel safe, you can grow powerfully.

------


# 19 Mut • Alltäglichkeit

Ihr Name bedeutet „Mutter“. Sie wird als Frau mit goldener Geierhaube dargestellt. Mut ist die Mutter aller Dinge und mit den Urwassern des Gottes Nun verbunden, aus denen alles Leben hervorgegangen ist. Sie symbolisiert beständige Schöpfung und die Erhaltung der Welt. Mut wird Dir ihre notwendige Präsenz schenken, wenn Du Dein Herz in die Arbeit steckst, um Deinem Zuhause und Deiner Familie Gutes zu tun. Durch respektvolles, regelmäßiges Verhalten und engagierte Hingabe kannst Du Wachstum und Wohlstand fördern, insbesondere im materiellen Bereich.

# 19 Mut • Being Ordinary

Her  name  means  “mother”. She  is depicted as a wom-an  wearing a golden  headdress in  the  likeness of  a vul-ture.  Mut  is  the  mother  of ail  things,  and  is  associat-ed  with  the  primordial  waters  of  the  God  Nun,  from whom everything in the world was born. She symbolises permanent  creation.  She  establishes  the  conservation of things.  Mut  will  offer you her  necessary presence  if you put  your  whole  heart  into  working  to  give benefit and  advantage to your home and  your family. You will only facilitate the production and  increase of  wealth, es-pecially material  goods, by maintaining  respectful  and regular behaviour on  a daily basis, through enthusiasm and dedication.

------


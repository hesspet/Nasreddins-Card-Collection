# 8 Seth • Groll

Seth ist derjenige, der aus Eifersucht seinen Bruder Osiris in vierzehn Teile zerschnitt und sie im Nil verstreute, um dessen Wiederauferstehung zu verhindern. Er wird als böse Gottheit und als Bringer von Chaos, Wüste, Stürmen und Unordnung betrachtet. Er wird mit menschlichem Körper und dem Kopf eines rätselhaften Tieres mit langer, gebogener Schnauze dargestellt, das an ein Okapi erinnert. Sein Name leitet sich von „Ort“, „festgelegt“ (von Gott) ab. Seth warnt Dich. Du könntest mit unerwarteten Unfällen, Momenten der Unruhe oder des Grolls, Konflikten oder Instabilität in emotionalen oder geschäftlichen Beziehungen konfrontiert werden. Mäßige Ausbrüche unkontrollierter Wut. Und denke daran: Greife niemals zur Rache in Deinem Leben!

# 8 Seth  • Resentment

Seth  is  the  one  who,  out  of  jealousy, dismembered  his brother  Osiris  into  fourteen  parts,  scattering  them  in the  Nile  to  prevent  their  resurrection.  He  is  identified as  an  evil  deity  and  a  bringer  of  chaos,  desert, storms and disorder. He is depicted with a human  body and the head  of an  enigmatic animal  with  a  long  curved  snout that  resembles that  of an  okapi. His  name  derives from “place”,  “established”  (by  God).  Seth  puts  you  on  your guard.  You  may  experience  unexpected  accidents,  mo-ments of  restlessness or resentment, conflicts or instabil-ity  in  emotional or commercial  relationships. Moderate any attacks of uncontrolled anger. Remember: never  re-sort to revenge in  your life!

------


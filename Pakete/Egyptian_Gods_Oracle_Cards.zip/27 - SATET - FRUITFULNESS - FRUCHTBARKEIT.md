# 27 Renentet • Reichtum

Göttin der Fruchtbarkeit und der Ernte. Sie wird mit dem Kopf einer Kobra oder als Frau mit einer Kobra auf der Stirn dargestellt. Renentet wacht über die Vorratskammern, die Fülle der Ernte und die Nahrung des Volkes. Sie schenkt Schutz, Versorgung und Reichtum. Unter ihrem Einfluss kannst Du auf materielles Wachstum, Erfolg im Beruf oder gute Erntezeit hoffen — im wörtlichen wie im übertragenen Sinn. Teile Deinen Wohlstand großzügig, denn geteilter Reichtum ist beständiger Reichtum.

# 27 Renentet • Wealth

Goddess of fertility and harvest. She is depicted with the head of a cobra or as a woman with a cobra on her forehead. Renentet watches over the granaries, the abundance of crops, and the nourishment of the people. She grants protection, sustenance, and wealth. Under her influence, you can expect material growth, professional success, or a good harvest — both literal and metaphorical. Share your wealth generously, for shared wealth is lasting wealth.

------


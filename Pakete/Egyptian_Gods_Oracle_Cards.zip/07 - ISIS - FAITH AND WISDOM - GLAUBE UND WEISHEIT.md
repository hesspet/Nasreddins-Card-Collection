# 7 Isis • Glaube und Weisheit

Schwester und Ehefrau von Osiris, sie wird mit der Muttergöttin verglichen. Ihr Name bedeutet „Thron“; tatsächlich wird sie mit einer Kopfbedeckung in Thronform dargestellt. Sie wird als ideale Mutter und Ehefrau verehrt. Sie ist die Beschützerin der Sünder und Unterdrückten sowie Göttin der Mutterschaft, Fruchtbarkeit und Großen Magie. Als Überbringerin von Gelassenheit in der Liebe lädt Isis Dich ein, über Themen wie Glaube, Wissen, Treue, Reinheit und Stille nachzudenken. Lerne, Geheimnisse zu wahren und auf den Glauben zu vertrauen. Indem Du Geheimnisse bewahrst, lernst Du zu schützen und große Verantwortung zu tragen – etwa das geheime Wissen über die Dualität von materieller und spiritueller Welt.

# 7 Isis • Faith and Wisdom

Sister and wife of  Osiris, she is compared to the Mother Goddess. Her  name  means “throne”; in fact, she  is  rep-resented with a  headdress in  the shape of  a throne. She is  revered as the  ideal  mother and  wife. She  is the  pro-tectress of  sinners and the oppressed, and the goddess of motherhood, fertility and  Great Magic. As a conveyor of serenity in  love, Isis invites you to reflect on  the  themes of  faith, knowledge, fidelity, purity and silence. Learn to work  on  keeping secrets  and  trust  in  faith.  By  keeping secrets you learn to protect and to bear great responsibil-ities, such as the secret knowledge of  the duality between the  material  universe and  the spiritual universe.

------


# 6 Osiris • Tod und Wiedergeburt

Er ist der älteste Sohn von Geb und Nut. Er wird oft als Mumie mit schwarzer oder grüner Haut dargestellt, was den Lebensgeist der Erde und der Vegetation symbolisiert. Osiris ist ein gerechter, mitfühlender Gott: Er ist der Gott des Leidens, der Opfer und der Unterdrückten – und leidet daher mit den Sterblichen. In ihm wohnen die gesamte Kraft der Fruchtbarkeit und der Fortpflanzung: der Zyklus von Tod und Wiedergeburt. Diese Karte kündigt das Ende eines Zyklus, einer Familienbeziehung oder Freundschaft an. Heiße eine neue Situation mit Zuversicht willkommen, auch wenn sie anders ist als das, was Du bisher erlebt hast. Gib die alte Ordnung auf. Und denke immer daran, für Dein Leben dankbar zu sein – Tag für Tag, im Guten wie im Schlechten. Nur so werden Ehre und Glück Deine Begleiter sein.

# 6 Osiris • Death and Rebirth

He  is  the  eldest  son  of  Geb  and  Nut.  He  is  often  de-picted  as  a  mummy  with  black  or  green  skin,  which symbolises  the  vital  spirit  of  the  earth  and  vegetation. Osiris is a just, compassionate god: he  is the  god of  suf-fering, victims and the oppressed, and as such  he suffers with  mortals. All the  power of  fertility and  reproduction resides  within  him:  the  cycle of death  and  rebirth. He presages  the  end  of a  cycle, of  a  family  relationship or friendship.  Welcome  a  new  situation  with  confidence, even if  it is different from what you have experienced up to  now.  Abandon  the  old  order.  And  always remember to be thankful for  your  life, day after day, whether it  is good or  bad.  Only  in  this way will  honour  and  luck  be your companions.

------


# 24 Taweret • Ursprung

Große Beschützerin schwangerer Frauen und Kinder, die selbst im Schlaf wachsam ist. Sie wird als schwangernes Nilpferd mit menschlicher Brust, Krokodilsschwanz und aufrechten Beinen dargestellt. Taweret gilt als Mutter der Sonne und unterstützt deren tägliche Wiedergeburt. Ebenso hilft sie den Verstorbenen, in ein neues Leben wiedergeboren zu werden. Sie steht für alles, was Schöpfung und Manifestation ermöglicht. Neue Projekte oder Nachrichten kündigen sich an — ein Beginn, ein Lebensereignis, eine neue Beziehung, die sich festigt, möglicherweise bis hin zur Ehe.

# 24 Taweret • Genesis

She  is  the  Great  Protectress  of  pregnant  women  and children, who is vigilant even in  her sleep. Goddess de-picted with the features of  a pregnant hippo with human breasts, standing on  two legs and  with  a crocodile’s tail on  her  back.  She  is  considered  the  mother  of  the  Sun and  collaborates in  his  daily  rebirth, as well as  helping the  deceased  to be  reborn  to a  new  life. She symbolises everything  that  leads  to  the  generation  of  things  and their  appearance. You could  start  some  new  projects or have news on  the way. The birth of  something new. The arrival of  a new life or the beginning of  a relationship in your  life,  both  in  the  beginning phase and  in  the  sense of  a bond that is welded, such  as a  marriage.

------


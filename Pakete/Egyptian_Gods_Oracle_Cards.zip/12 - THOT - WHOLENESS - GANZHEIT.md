# 12 Thot • Ganzheit

Gott in Menschengestalt mit dem Kopf eines Ibis oder als Pavian, Mondgott, Symbol der Weisheit, „Herr der Zeit“. Er ist der Beschützer der Schreiber und Erfinder der Schrift, der Gott der Magie, der Hellsicht und der Gesetze. Er hilft Anubis beim Richten der Seelen und bei Entscheidungen über ihr Schicksal. Von Dir wird Selbstdisziplin verlangt, denn das ist der Schlüssel zum Fortschritt. Lerne, Deine intelligenten Ressourcen zu nutzen, wenn Du Vorhaben erfolgreich abschließen willst. Lerne, ganz zu sein und unmoralische Tendenzen abzulehnen; sei unparteiisch in allem, was Du tust, wenn Du ein vollständiges und gerechtes Leben anstrebst.

# 12 Thot  • Wholeness

Human-shaped deity with  the  head  of an  ibis or  in  the form  of  a  baboon,  moon  god, symbol  of wisdom,  “Lord of  Time”. He is the  protector of  scribes and  the inventor of writing, the  god of magic, clairvoyance and  laws.  He assists  Anubis  in  judging  souls  and  reaching  decisions on their fate. You are  required to show self-discipline as this is the  key to success in  making progress. Learn  how to  use  intelligent  resources  if  you  want  to  successfully complete certain  enterprises.  Learn  to  be  whole  and  to reject immoral tendencies; be impartial in  all the things you do, if you want to pursue a complete and  just life.

------


# 20 Khonsu • Einsiedelei

Gott des Mondes, der Zeit und des Wissens. Sein Name bedeutet „Reisender“, „Wanderer“. Khonsu ist der Lenker menschlicher Schicksale. Er wird als mumifizierter Knabe dargestellt. Er verkörpert die Schönheit der Jugend, das Staunen und die Spontaneität. Wie andere Kindgottheiten symbolisiert er das Potenzial, das in jedem von uns schlummert. Sei offen für neue Ideen und mutig, dem Unbekannten zu begegnen. Auch Reisen, die Dich aus Deiner Komfortzone führen, sind möglich. In der Liebe kann ein günstiger Neubeginn bevorstehen.

# 20 Khonsu • Hermitage

God of  the moon, time and  knowledge. His name means “traveller”,  “the  wanderer”.  Khonsu  is  the  admiral  of human destinies. He  is depicted as a  mummified young child. He represents the synthesis of  the beauty of  youth, the  archetype  of  youthful  amazement  and  spontaneity. Like other child deities, he symbolises the potential that lies in  all  of us. Be open  to new  ideas and  be brave and bold  in  facing  up  to  the  unknown  that  presents  itself to  you.  Possibility  of  journeys  that  take  you  away from your  “comfort  zone”.  In  love  you  may  experience  new favourable beginnings.

------


# 11 Anubis • Transformation

Er ist der Beschützer der Gräber, der Einbalsamierer der Toten und der Begleiter der Seelen ins Jenseits, wo ihre Herzen gewogen und sie vom irdischen Dasein in die Gegenwart des Osiris überführt werden. Anubis wird als Mann mit einem Schakalskopf dargestellt. Er symbolisiert die Erneuerung des Lebens selbst, Wiedergeburt und Regeneration. Du stehst kurz vor dem Ende eines Zyklus oder befindest Dich bereits in einem neuen: mögliche Enttäuschungen, Zusammenbruch von Bindungen, Verluste. Fürchte Dich nicht — Anubis wird Dich während der Transformation begleiten und führen. Nichts wird so sein wie zuvor, denn alles wird sich unvermeidlich wandeln. Aber Du kannst ein neues Leben in neuer Form erschaffen.

# 11 Anubis • Transformation

He is the  protector of  tombs, the embalmer of  the dead, who accompanies souls  into the  afterlife to weigh their hearts  and  ferry  them  from  the  earthly  world  into  the presence of  Osiris. Anubis is portrayed as a jackal-head-ed man. He symbolises the  renewal of  life itself, rebirth and  regeneration. You are  about  to  end  a  cycle or  you are  already  experiencing  a  new  one:  probable  disap-pointments, collapse of affections, losses. Do not  worry, Anubis  will  accompany  you and  guide  you during  the transformation  of elements.  Nothing will  return  to the way it  was before,  inevitably everything is  transformed but all you can do is create a new life in a new form.

------


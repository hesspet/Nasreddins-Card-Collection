# 18 Khepri • Wandel

Gott der täglichen Wiedergeburt der Sonne und des zyklischen Neubeginns. Er wird durch einen Skarabäus dargestellt, schwarz wie die Dunkelheit, der Ursprung aller Dinge. Er symbolisiert die Verwandlung des Menschen durch die Stadien Leben – Tod – Wiedergeburt, den Sieg des Lichts über die Dunkelheit, des Lebens über den Tod. Sein Erscheinen kann das Ende eines Zyklus ankündigen, einen Zusammenbruch, Enttäuschungen oder das Zerbrechen von Bindungen. Aber alles wandelt sich ständig – wie Tag und Nacht. Khepri ermutigt Dich, jeden Tag mit dem Licht des Glaubens und der Hoffnung aufzustehen, denn nach jeder Nacht bricht ein neuer Tag an.

# 18 Khepri • Change

God  of  the  Sun’s  daily  rebirth  and  of  cyclical  renewal. Represented  by  a  scarab,  Khepri  is  black  as  darkness, the  beginning  of  all  things.  He  symbolises  the  trans-formation  of  humans  in  their  stages: life-death-rebirth, the  victory  of  light  over  darkness,  of  life  over  death, the  becoming,  the  generative  power  symbol  of  rebirth. His  appearance  might  announce  the  end  of  a  cycle, a breakdown,  disappointments  or  the  wrecking  of  affec-tions.  But  everything  is  constantly  changing,  like  day and  night,  and  Khepri  encourages  you  to  get  up  every day  with  the  light  of faith  and  hope  because  after  the night a new day always dawns.

------


# 4 Nut • Verständnis

Göttin des Himmels und der Himmelskörper. Sie verschlingt die untergehende Sonne und gebiert sie am Morgen. Ihr gewaltiger nackter, mit Sternen bedeckter Körper ist zu einem Bogen ausgestreckt, der sich über die ganze Erde wölbt. Ihre gewölbte Haltung zeigt deutlich ihre Macht am Himmel und über die Himmelsobjekte. Ihre Nacktheit steht für die Reinigung der Seele. Die Sterne, die sie bedecken, symbolisieren die Auferstehung – das große Licht, das erleuchtet. Dein Leben ist eine geheimnisvolle Reise. Du bist an diesem Punkt angekommen, und Nut möchte Dir helfen, Deinen Zweck und Dein Schicksal zu verstehen. Geh zuversichtlich weiter, denn jetzt „weißt“ Du, dass am Horizont günstige Ereignisse liegen – und Du Deine gewünschten Ziele erreichen könntest.

# 4 Nut • Understanding

Goddess  of  the  sky  and  celestial  bodies.  She  swallows the setting sun  and  gives birth  to it in  the  morning. Her immense  naked  body covered with  stars  is stretched  out to  form  an  arch  that  towers over  the  whole  earth.  Her arched  position  clearly shows  her  power in  the  sky  and over  the  celestial  objects. Her  nakedness  represents  the purification of the soul. The stars that cover her symbol-ise the resurrection, the great light that illuminates. Your life is a  mysterious journey. You have reached  this  point and  Nut  wants  to  help  you  to  understand  your  purpose and  your destiny.  Press on  with  confidence  because  now you  “know” that  there  will  be  favourable  events  on  the horizon, and  you might achieve your desired objectives.

------


# 23 Sobek • Vereinigung und Macht

Eine zwiespältige Gottheit — sowohl gefährlich als auch beschützend. Seine Wildheit kann das Böse abwehren und gleichzeitig die Unschuldigen verteidigen. Sein Name leitet sich von „vereinigen“ ab (die Glieder des zerstückelten Osiris). Sobek wird als Krokodil oder krokodilköpfiger Mann dargestellt. Er heilt die Seelen der im Kampf Verwundeten oder Gefallenen und stellt ihre Sinne und Gesundheit wieder her. Sobek steht für Entscheidungs- und Handlungskraft sowie die Umsetzung von Plänen. Unter seinem Einfluss verfügst Du über eine stabile Basis für große Vorhaben. Gib nicht auf — Deine Anstrengungen werden Früchte tragen und Dir Macht verleihen.

# 23 Sobek • Union and  Power

This  is an  ambivalent divinity, both  malignant and  be-nign.  His  ferocity  is  able  to  ward  off  evil  and  at  the same time defend  the  innocent. His  name derives from “unite” (the dismembered limbs of  Osiris). Sobek is usu-ally portrayed as a crocodile or a crocodile-headed man. He  heals the souls who were wounded or  killed  in  bat-tle, restoring their  health, sight and all their senses. He represents  the  authority  of decision-making  power and action  and  the  implementation  of  projects. Under  the influence of  Sobek, you have a sound  base on which  to build  large  business-like enterprises.  Do not stop: your effort will bear fruit and allow you to gain  power.

------


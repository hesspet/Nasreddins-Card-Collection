# 5 Geb • Wohlstand

Gott der Erde und aller Tiere. Er wird üblicherweise liegend auf dem Boden dargestellt, mit Pflanzen und Früchten auf seinem Körper, oder als bärtiger Mann mit einer Gans auf dem Kopf – ein Emblem, das den Hieroglyphen seines Namens repräsentiert. Geb symbolisiert Reichtum, Fruchtbarkeit und die Fülle der Natur – aber auch ihre gefürchtetsten Kräfte. Mit Geb kannst Du auf langsame, aber stetige Entwicklung vertrauen, etwa die Verwirklichung eines Projekts oder den Abschluss eines Programms. Du könntest äußerst angenehme, ruhige und zärtliche Gefühle erleben, voller Harmonie und moralischer Integrität.

# 5 Geb • Prosperity

God  of the  earth  and  all  animals. He  is  usually depict-ed  lying  on  the  ground,  with  plants  and  fruit  on  his body, or as a bearded man  with a goose on  his head, the emblem  representing  the  hieroglyph  of  his  name.  Geb symbolises wealth, fertility and abundance of  nature, but also  its  most  feared  forces.  With  Geb  you  can  trust  in slow  but  constant development, such  as  the  realization of a  project or  the  conclusion  of a  program. You might experience extremely pleasant, tranquil and tender emo-tions, full of harmony and  moral  integrity.


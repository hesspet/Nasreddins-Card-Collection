# 26 Serket • Mut und Abenteuer

Skorpiongöttin, die auf dem Kopf einen Skorpion trägt, mit ausgebreiteten Armen und Schutzflügeln. Sie ist Göttin des Lebens und der Fruchtbarkeit, aber auch der Heilung, Wächterin des Jenseits und Beschützerin des Pharaos. Sie kann tödliche Skorpionsstiche heilen, das Böse bekämpfen und durch ihre Magie schützen. Serket kündigt einen neuen Zyklus voller Abenteuer, Unabhängigkeit, Mut und Risiko an. Du könntest bald etwas Ungewöhnliches erleben oder auf Reisen gehen. Dies ist eine Zeit des Aufbruchs und der Lebendigkeit. Lass Dich auf das Neue ein, aber handle mit Verantwortung.

# 26 Serket • Courage and Adventure

Scorpion goddess, represented with a scorpion on her head, with open arms and protective wings. She is a goddess of life and fertility but also of healing, guardian of the afterlife and protectress of Pharaoh. She can cure deadly scorpion stings, counteract evil, and protect through her magic. Serket foretells the start of a new cycle, bringing adventures, independence, courage and risk. You might soon experience something out of the ordinary or go on a journey. This is a time of departure and liveliness. Embrace the new, but act responsibly.

------


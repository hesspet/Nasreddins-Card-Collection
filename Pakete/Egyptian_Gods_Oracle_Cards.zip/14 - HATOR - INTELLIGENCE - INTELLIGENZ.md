# 14 Hator • Lebensfreude und Intelligenz

Sie ist die Mutter aller Frauen, Göttin der Liebe, Leidenschaft und Schönheit. Ihre Feste sind rauschhafte Feiern voller Freude und Musik. Hator wird auch mit Geburt, Entbindung und Kindern assoziiert. Sie erscheint als junge Frau mit Kuhhörnern und einer Sonnenscheibe dazwischen, weshalb man sie auch „Göttliche Kuh“ nennt. Doch auch sie hat eine zerstörerische Seite. Diese Karte lädt Dich ein, angenehme Situationen zu schaffen und den Moment zu genießen. In der Liebe hilft Hator, Sexualität und Sinnlichkeit zu intensivieren, Lebensfreude und kreative Fülle zu entfalten. Auch materieller Wohlstand kann wachsen.

# 14 Hator • Intelligence

She  is  the  Mother  of all  women, She  is  the  goddess  of love, passion and  beauty: her  parties are orgies of intox-ication, joy and  music. She  is also associated with child-birth, delivery and children. She is portrayed as a young woman  with  cow  horns  on  her  head;  the  sun  disc  is placed between the  horns which is why she is also called the  “Divine  Cow”.  But  she  also  has  a  destructive  side. Try  to  create  pleasant situations, and  make  the  most of the  moments  you  experience.  In  love,  Hator  helps  to intensify sexuality,  the  senses,  the  explosion  of  life,  of everything capable  of being  born.  Increase of wealth  in all areas, especially material ones.

------


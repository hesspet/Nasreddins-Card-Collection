# 17 Sekhmet • Gerechtigkeit

Löwenköpfige Göttin mit Sonnenscheibe auf dem Kopf. Sekhmet ist die Göttin des Krieges und der Epidemien, aber auch Beschützerin der Heilung. Sie verkörpert die Dualität zwischen Krankheit und Heilung, Chaos und Ordnung, Wasser und Feuer — die beiden Elemente, aus denen Materie und Geist entstehen. Sekhmet bringt Ordnung und bestraft jene, die göttliches Gesetz missachten. Du hast die Möglichkeit, gegensätzliche Energien zu versöhnen. Denk daran: Jede Handlung hat Konsequenzen. Sei ruhig und geduldig. Meide Extreme. Sei Dein eigener Magier — bring Deinen Willen und Deine Ziele ins Gleichgewicht. Sei gerecht und fair. Lerne, konstruktiv zu urteilen und zu kritisieren, ohne zu verletzen.

# 17 Sekhmet • Justice

Lioness-headed female goddess with a sun disc on  her head. Sekhmet is the  divinity of war, epidemics but  also the  pro-tectress  of  forms  of  healing.  She  is  the  expression  of  the duality between disease and  healing, chaos and order, water and fire, the two elements from which  matter and spirit are obtained. Sekhmet brings order and punishes those who dis-obey divine  law. You have  the  opportunity to  reconcile  the opposing  energies.  Remember  that  all  the  chickens  come home  to  roost.  Every  person  must  experience  the  conse-quences of  their actions, for better or for worse. Every action or  thought generates  a  consequence.  Proceed  more  calmly and  patiently. Avoid extremes. Be  your  own  magician,  bal-ance your will  and  your goals. Be just and  be fair. Learn to judge and criticise constructively, without hurting others.

------


# 21 Khnum • Einfallsreichtum

Er wird oft mit menschlichem Körper und Widderkopf dargestellt. Khnum gilt als göttlicher Töpfer: Er gibt seinen Schöpfungen Leben, indem er sie auf einer Drehscheibe aus Nilton formt. Er formte auch das Ei der Schöpfung. Er ist eine Gottheit, die mit männlicher Fruchtbarkeit, Schaffenskraft und dem Element Feuer verbunden ist, das im Widder-Symbol enthalten ist. Khnum wird als Lebensspender angesehen. Neue, positive Anfänge oder die Geburt von etwas Mächtigem und Inspirierendem kündigen sich an — etwa die Entstehung und Produktion neuer Werke. Tatkraft und Einfallsreichtum unter Khnums Einfluss tragen Früchte.

# 21 Khnum • Resourcefulness

He  is  often  represented  with  a  human  body and  the head  of  a  ram.  He  is  considered  the  divine  maker  of pots: he gives life to his creations by modelling them on a lathe with clay from the Nile; he also shaped the egg of creation. He is a deity associated with  male fertility and procreative potency, fire,  inherent in  the symbol of the ram.  In  breathing new life into  things,  Khnum  is seen as a  health giver. New, positive beginnings or the  birth of  something powerful and  inspiring in  your life, lie on the horizon for you, such as the creation and production of  new things. Action and resourcefulness under the in-fluence of Khnum are bearers of  fruits.

------


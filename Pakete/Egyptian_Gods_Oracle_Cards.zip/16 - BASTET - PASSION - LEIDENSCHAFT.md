# 16 Bastet • Leidenschaft

Katzenköpfige Göttin oder als schwarze Katze dargestellt. Sonnengöttin, sie verkörpert die wohltuende Wärme der Sonne. Beschützerin des Hauses und der Katzen. Göttin des Wohlstands und Reichtums. Sie steht für Sinnlichkeit und Zärtlichkeit, Charme und Großzügigkeit, Liebe und Leidenschaft, Lust und Freude. Vielleicht solltest Du eine Pause von Deinem Alltag nehmen und Dich wieder mit der Natur und Dir selbst verbinden. Lebe Dein Leben mit mehr Intensität und Leidenschaft. In Dir liegt die Fähigkeit, Anziehungskraft und Leidenschaft zu entfalten. Du könntest in jedem Lebensbereich große Erfüllung erleben.

# 16 Bastet • Passion

Cat-headed female deity or portrayed as a black cat. Sun goddess, she  personifies  the  beneficial  heat  of the  sun. Protectress of  the  house and  cats. Goddess of  prosperity and  wealth.  She  represents  sensuality  and  tenderness, charm and generosity, love and passion, desire and  plea-sure. Maybe you should take a break from  your routine and  reconnect with  nature and with  yourself. Live your life with  more fullness and  passion. It  lies within  your ability to develop seduction  and  passion. You could get great satisfaction in any area of  your life and experience moments full of   joy and satisfaction.

------


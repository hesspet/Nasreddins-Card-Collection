# 2 Amon-Ra • Schöpfung

Er ist die mächtigste kosmische Gottheit, denn er ist der König aller Götter im ägyptischen Pantheon. Er entstand aus der Verschmelzung des Gottes „Ra“ von Heliopolis mit der thebanischen Hauptgottheit „Amun“. Amun-Ra ist der Schöpfer aller Dinge. Als Symbol für Intelligenz und Kreativität ist er wie Feuer – schnell und oft unerwartet. Erscheint Dir diese Karte, verfügst Du über alle Fähigkeiten, um zu erhalten, was Du willst: geistige und praktische Fertigkeiten, um Deine Ziele zu erreichen. Sie weist auf eine blühende Zeit hin, auf Kompetenz in Öffentlichkeitsarbeit, auf Ideen und Absichten, die Gestalt annehmen; vielleicht sogar auf ein plötzliches Verliebtsein, einen Neubeginn oder auf eine Liebesgeschichte, die Form annimmt.

# 2 Amon-Ra • Creation

He  is the  most  powerful  cosmic deity, as he  is the  king of  all gods in the Egyptian  Pantheon. He was born from the  fusion  of the  god “Ra” of Heliopolis with  the  main Theban  deity:  “Amon”,  Amon-Ra  is  the  creator  of  all things. Symbol  of intelligence and  creativity,  he  is  like fire,  rapid  and  often  unexpected.  If  this  card  appears to you,  you  have all  the  skills to obtain  what  you want: intellectual and  practical skills for achieving your objec-tives. He  indicates a flourishing period, skills in  public relations, ideas and intentions which take concrete form; perhaps even  a sudden falling in  love, a  new beginning or a love story that takes shape.

------


# 13 Maat • Wahrheit und Gerechtigkeit

Göttin der Harmonie, Gerechtigkeit und Wahrheit. Sie wird meist als junge Frau mit Flügeln oder mit einem Lebensstab dargestellt — einem Symbol des ewigen Lebens. Auf ihrem Kopf trägt sie eine Straußenfeder als Symbol der Leichtigkeit. Maat steht auch für die universelle Ordnung. Alles Dasein bewegt sich im Rahmen des Prinzips der Gerechtigkeit, das als zu befolgende Gesetzmäßigkeit verstanden wird. Es ist Zeit für Erneuerung und Wiederherstellung. Du könntest für richtige Taten belohnt oder für falsche Handlungen Konsequenzen erfahren. Denk daran: Wahres Glück kann nur durch Fairness, Rechtschaffenheit und Mäßigung erreicht werden.

# 13 Maat  • Truth  and  Fairness

Goddess  of  harmony,  justice  and  truth.  She  is  usually depicted  as  a  young woman  with  wings or  holding the sceptre of power, a symbol of  eternal life. She  wears an ostrich feather on  her  head, a symbol of  lightness. Maat also  represents  universal  order. All  existence  moves on the  basis of the  principle of  justice, interpreted as a law that  must  be observed. It is time for  recovery and  resto-ration. You may receive rewards for certain right actions but also punishments and consequences for wrong ones. Remember that  happiness can only be achieved through fairness, righteousness and  moderation.

------


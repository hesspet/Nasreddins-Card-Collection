# 10 Nefhti • Meditation

Gattin von Seth und jüngere Schwester von Isis, Göttin der Unterwelt und des Todes im Allgemeinen. Ihr Name bedeutet „Herrin des Hauses“ und weist darauf hin, dass sie Herrin des Tempels ist – ein Hinweis auf ihre priesterlichen Funktionen. Sie repräsentiert den Zugangsweg zu Heiligtümern und zum Horizont. Nefhti schützt Menschen und ihre Seelen im Moment des Übergangs. Hindernisse, Verluste oder schmerzhafte Ereignisse können unerwartet und unumkehrbar auftreten. Lerne, dass durch Nachdenken alles vollständig verwandelt und entwickelt werden kann. Deine Fähigkeit, weiter aufzusteigen, hängt allein von Deinem eigenen Gewissen ab.

# 10 Nefhti • Meditation

Wife of  Seth  and  younger sister  of  Isis, goddess of the underworld  and  of death  in  general.  Her  name  means “Lady of  the  House”,  which  indicates  that  she  is  the Lady of  the Temple, with  reference to her  priestly func-tions. She  represents the  access road to sanctuaries and the  horizon.  Nefthi  protects  humans  and  their  souls in  the  moment  of  passing  away. Obstacles,  losses,  or painful  events may arise  unexpectedly and  irreversibly. Learn  that  through  reflection  everything  can  be  fully transformed  and  developed. Your ability  to continue  to rise up depends only on your own conscience.

------


# 22 Anuket • Hoffnung

Sie wird als Frau mit hohem Feder- oder Schilfkopfschmuck dargestellt, seltener als Gazelle. Als Göttin des Nils ist sie mit seinen lebensspendenden Überschwemmungen verbunden, die Fruchtbarkeit und Wohlstand bringen. Ihr Name bedeutet „die, die umgibt“ — eine Anspielung auf das Wasser, das das Land einnimmt und alles Leben nährt. Sie steht für Großzügigkeit und die Gabe des Lebens. Vertraue auf den Schutz Anukets, die Dich führen und Deinen Mut stärken wird. Sie schenkt Dir Intensität und Hoffnung, auch wenn Opfer oder Verzicht erforderlich sind. Hoffnung liegt im Herzen des Optimisten.

# 22 Anuket • Hope

She is depicted as a woman with a high  headdress made of  reeds  or  ostrich  feathers;  more  rarely  she  is  repre-sented in the form of  a gazelle. Being the goddess of  the Nile,  she  is  linked  to  its floods, which  bring  nourish-ment, fertility and prosperity to the earth. This is where she  gets  her  name:  “She  who surrounds”,  that  is,  her invasion of  the lands that embrace every being to bring fertility  and  happiness.  She  represents  the  generosity that gives rise to life. Trust in  the  protection of  Anuket who will guide you and  bolster your courage, who gives you  intensity  and  hope,  even  when  renunciations  and sacrifices arise. Remember  that  hope is in  the  heart  of the optimist.

------


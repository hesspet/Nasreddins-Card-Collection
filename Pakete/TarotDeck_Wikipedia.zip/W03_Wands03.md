**DREI DER STÄBE**

Eine ruhige Gestalt beobachtet von einer Klippe aus Schiffe auf See. Drei Stäbe sind in den Boden gepflanzt, einer stützt die Figur.

* Stärke, Handel, Entdeckung, Erfolg. 
* **Umgekehrt:** Ende von Schwierigkeiten, Enttäuschung, Mühsal. 

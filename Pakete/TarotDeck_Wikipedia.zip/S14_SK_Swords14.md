S14_Swords14.jpg

**DIE STÄRKE/STRENGTH**

* Kraft, Energie, Tatkraft, Mut, Großmut.
* **Umgekehrt:** Machtmissbrauch, Despotismus, Schwäche, 
  Zwietracht.

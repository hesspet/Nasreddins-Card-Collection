**DER MAGIER/THE MAGICIAN** 

* Geschicklichkeit, Diplomatie, Takt, Krankheit, Schmerz, Verlust, Katastrophe, Selbstvertrauen, Wille, der Fragende selbst (wenn männlich). 
* **Umgekehrt:** Arzt, Magier, Geisteskrankheit, Schande, Unruhe.

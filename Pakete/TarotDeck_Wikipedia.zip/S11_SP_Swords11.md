S11_Swords11.jpg

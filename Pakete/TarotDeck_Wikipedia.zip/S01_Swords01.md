S01_Swords01.jpg

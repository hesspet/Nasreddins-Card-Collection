**DIE GERECHTIGKEIT/JUSTICE**

* Gerechtigkeit, Rechtschaffenheit, Integrität, Exekutive.
* **Umgekehrt:** Gesetz in allen Bereichen, Engstirnigkeit, Vorurteil, übermäßige Strenge.

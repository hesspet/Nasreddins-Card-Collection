**ZEHN DER STÄBE**

Ein Mann, der von der Last von zehn Stäben überwältigt wird.

* Unterdrückung, Erfolg, Gewinn, Verkleidung, Betrug. Erfolg wird beeinträchtigt, wenn die Neun der Schwerter folgt. Bei einer Rechtsangelegenheit droht sicherer Verlust. 
* **Umgekehrt:** Widersprüche, Schwierigkeiten, Intrigen. 

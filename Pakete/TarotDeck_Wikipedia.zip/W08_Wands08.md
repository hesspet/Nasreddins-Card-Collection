**ACHT DER STÄBE**

Eine Darstellung von Bewegung – Stäbe fliegen durch eine offene 
Landschaft.

* Wahrsagerische Bedeutung: Aktivität, Geschwindigkeit, Hoffnung, Bewegung zum Ziel. Auch „Pfeile der Liebe“. 
* **Umgekehrt:** Eifersucht, interne Streitigkeiten, Gewissensbisse, 
  Auseinandersetzungen. 

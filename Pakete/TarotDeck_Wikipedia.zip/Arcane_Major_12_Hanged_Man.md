**DER GEHÄNGTE/THE HANGED MAN**

* Weisheit, Prüfungen, Umsicht, Unterscheidung, Opfer, Intuition, Weissagung, Prophezeiung.
* **Umgekehrt:** Egoismus, die Masse, der Staatskörper.

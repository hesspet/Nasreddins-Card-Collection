S02_Swords02.jpg

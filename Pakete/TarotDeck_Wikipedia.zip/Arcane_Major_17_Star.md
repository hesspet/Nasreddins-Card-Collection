**DER STERN/THE STAR**

* Verlust, Diebstahl, Entbehrung, Verlassenheit, obwohl eine andere Lesart Hoffnung und positive 
  Aussichten für die Zukunft vorschlägt. 
* **Umgekehrt:** Arroganz, Impotenz, Hochmut.

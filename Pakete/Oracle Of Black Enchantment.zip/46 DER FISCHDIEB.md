# 46 DER FISCHDIEB

Ein hungriger Junge versucht, mit einem Fisch davonzulaufen, 
den er aus dem Meer gestohlen hat. Eine Meerjungfrau taucht 
aus den Wellen auf und packt seinen Knöchel, während ihre 
Schwestern den Möchtegerndieb zurechtweisen.
## Dunkle Bedeutung:
Zu lang warten, um ein Problem zu verhindern. Dabei ertappt 
werden, etwas Falsches zu tun. Sein Verhalten erklären müssen. 
Peinlichkeit.
## Helle Bedeutung:
Jemanden auf frischer Tat ertappen. Ein schlechtes Ereignis 
verhindern. Ein Problem frühzeitig erkennen und stoppen.
# 11 VERSCHÜTTETE GEHEIMNISSE

Skelettierte Sargträger lassen den schwarzen Sarg, den sie 
zum Grab trugen, fallen und enthüllen dabei den Körper 
einer ermordeten Frau.
## Dunkle Bedeutung:
Ein schwerwiegender Fehler mit schlimmen Folgen. 
Versagen. Inkompetenz. Mangelnde Zusammenarbeit. 
## Helle Bedeutung:
Böse Taten, die endlich ans Licht kommen. Die Wahrheit 
aufdecken.
# 49 DIE PRÜFUNG

Die verblindete Hexe schreitet furchtlos in die Dunkelheit voran. 
Mit jedem Schritt vertreibt sie die Angst und erschafft ein Leben 
voller Freude und Sinn.
## Dunkle Bedeutung:
Sich von der Dunkelheit verzehren lassen. Feigheit. Mangel an 
Glauben. Die Zustimmung anderer benötigen, bevor man 
voranschreitet.
## Helle Bedeutung:
Jemand, der bereit ist, durch die Dunkelheit zu gehen, um das 
Licht zu finden. Tapferkeit. Blinder Glaube an die eigenen 
Fähigkeiten. Das Wissen, dass man Probleme lösen wird, sobald 
sie auftreten.
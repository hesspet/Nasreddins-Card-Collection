# 29 LEVITATION

Ein talentierter Magier schwebt langsam in die Luft, 
während die Stadtbewohner vor Staunen den Atem 
anhalten.
## Dunkle Bedeutung:
Seltsame Kräfte, die sich nicht leicht erklären lassen. Eine 
dunkle Machtdemonstration. Eine glaubhafte Illusion 
über leichtgläubige Menschen.
## Helle Bedeutung:
Die Fähigkeit, Begrenzungen zu überwinden. Ein 
Wunder. Verborgene Fähigkeiten treten zutage. Sich über 
die Masse erheben.
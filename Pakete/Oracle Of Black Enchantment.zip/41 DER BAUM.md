# 41 DER BAUM
Ein uralter Baum steht tief im Wald. Während die 
Jahreszeiten andere Bäume ihre Blätter verlieren lassen, 
behält dieser alte Baum sein volles Laub.
## Dunkle Bedeutung:
Eifersucht. Neid auf den Erfolg oder sozialen Status eines 
anderen. Der Versuch, jemanden auf ein beklagenswertes 
Niveau herabzuziehen, um sich selbst besser zu fühlen. 
Größe inmitten von Mittelmäßigkeit.
## Helle Bedeutung:
Weisheit. Die eigenen natürlichen Gaben nutzen, um aus 
der Masse hervorzustechen. Eine alte Seele, die trotz der 
Mühen des Lebens aufblüht.

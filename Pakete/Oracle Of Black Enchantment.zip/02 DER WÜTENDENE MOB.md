# 02 DER WÜTENDENE MOB

Eine bunt zusammengewürfelte Menge empörter Bürger 
marschiert trotzig gegen das Böse. Ohne ihr Wissen hat 
sich die Dunkelheit bereits in die Gruppe eingeschlichen. 

## Dunkle Bedeutung:
Kräfte, die sich gegen deine Ambitionen erheben. Starker 
Widerstand. Meuterei. Aufstand. Ein Störfaktor.

## Helle Bedeutung:
Einigkeit. Zusammenkommen für eine gemeinsame Sache. 
Zusammenschluss.ng together for a common cause. 
Coalescence.
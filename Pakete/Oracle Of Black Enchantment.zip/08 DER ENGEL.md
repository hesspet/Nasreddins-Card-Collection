# 08 DER ENGEL

Ein glorreicher Engel steigt aus den Wolken herab, um 
den Dämon daran zu erinnern, nicht so frei zu sprechen. 
## Dunkle Bedeutung:
Klatsch. Böse Gerüchte. Aufhetzende Bemerkungen. 
Rufschädigung. Faule oder verletzende Sprache.
## Helle Bedeutung:
Diskretion. Situationen, die Manieren und Etikette 
erfordern. Keine Angst, jemanden für seine Verfehlungen 
zur Rede zu stellen.


# 21 DER ANGRIFF

Ein Rudel furchterregender Löwen zerfleischt einen 
Dämon, entschlossen, ihn in Stücke zu reißen. Auch 
wenn er sich zur Wehr setzt, ist der Dämon den Bestien 
nicht gewachsen.
## Dunkle Bedeutung:
Ein überwältigender Angriff. Eine grausame Attacke. 
Von mehreren Gegnern gleichzeitig angegriffen werden. 
Gegen viele Feinde kämpfen.
## Helle Bedeutung:
Alles einsetzen, um ein Problem anzugehen. Keine 
Gnade. Unnachgiebig sein.
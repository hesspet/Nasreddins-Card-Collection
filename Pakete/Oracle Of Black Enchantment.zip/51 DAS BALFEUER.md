# 51 DAS BALFEUER

Bei einem mondbeschienenen Ritual springen die verruchten 
Paare gemeinsam über das Lagerfeuer, feiern ihre Fruchtbarkeit 
und ehren die Natur. Gereinigt durch die lodernden Flammen, 
ziehen sie in den Wald, um neues Leben zu zeugen.
## Dunkle Bedeutung:
Sündige sexuelle Beziehungen. Wildes oder obszönes 
Verhalten. Das Versäumnis, eine langjährige Tradition 
aufrechtzuerhalten.
## Helle Bedeutung:
Negative Energien beseitigen. Reinigung. Ein Übergangsritus. 
Feier und Tradition. Feurige Leidenschaft. Fortpflanzung.
# 36 DIE SCHLANGE

Eine furchteinflößende Schlange ringelt ihren Körper 
und bereitet sich auf den Angriff vor. Fünf Köpfe 
tauchen aus ihrem Schwanz auf und erinnern das Biest 
an die Seelen, die es im Kampf bezwungen hat.
## Dunkle Bedeutung:
Egoistische Aggression. Materieller Gewinn oder 
Macht, die auf Kosten anderer errungen wurde. 
Ausbeutung. Ein Diktator oder autoritärer Herrscher. 
## Helle Bedeutung:
Kann einen Anführer darstellen, der erkennt, dass seine 
Macht vom Volk ausgeht. Eine aggressiv starke 
Organisation oder politische Partei.
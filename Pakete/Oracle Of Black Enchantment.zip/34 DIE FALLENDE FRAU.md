# 34 DIE FALLENDE FRAU

Eine Frau stürzt von ihrem hohen Balkon und fällt 
hilflos durch die Nacht. Da nichts ihren Fall aufhält, 
wird sie beim Aufprall auf den harten Boden 
unweigerlich sterben.
## Dunkle Bedeutung:
Hilflosigkeit oder Unsicherheit. Die Kontrolle verlieren 
und dem Schicksal erliegen. Angst.
## Helle Bedeutung:
Eine Zeit, loszulassen und zu vertrauen, selbst in einer 
scheinbar aussichtslosen Lage. Annehmen, was man 
nicht kontrollieren kann.
# 07 ASTRALREISE

Ein junges Mädchen kuschelt sich in ihr warmes Bett und 
träumt die Nacht hindurch. Ihre unterbewusste Energie 
überschreitet die Grenzen ihres sterblichen Körpers und 
tritt in eine neue Dimension der Möglichkeiten ein. Sie 
muss jedoch aufpassen, nicht zu weit abzudriften, denn 
eine Gruppe hinterhältiger Geister will ihre spirituelle 
Verbindung durchtrennen und ihre Seele stehlen.
## Dunkle Bedeutung:
Verwundbarkeit. Sich exponieren. Risiko.
## Helle Bedeutung:
Über die eigenen Grenzen hinausgehen. Verbindung zum 
Geist. Vision..
# 38 TOTENBETT
Mondlicht fällt auf den Körper einer alten Frau, die 
friedlich im ewigen Tod schläft. Die Schönheit des 
Lebens, das sie einst führte, hat sich in ein herrliches 
Blumenbett verwandelt.
## Dunkle Bedeutung:
Nicht erleben, was man mühsam geschaffen hat. 
Verpasste Belohnungen. Nicht erkennen, was man einst 
besaß.

## Helle Bedeutung:
Ein Teil von dir lebt für immer weiter. Das Vermächtnis 
eines erfüllten Lebens. Unvergängliche Gaben. 
Beständige Liebe.


# 12 DIE HEILENDE HEXE

Die Weiße Hexe nutzt ihre heilenden Kräfte, um ein 
krankes Kind von seinen Leiden zu befreien. Ein grotesker 
Dämon steigt aus dem Mund des Jungen, als die Krankheit 
endlich seinen Körper verlässt.
## Dunkle Bedeutung:
Eine schlimme oder langanhaltende Krankheit. Niedrige 
Energie. Körperliche oder geistige Erschöpfung. Sorge um 
eine geliebte Person.
## Helle Bedeutung:
Eine Heilung. Hilfreiche medizinische Unterstützung. 
Güte und Mitgefühl. Genesung.
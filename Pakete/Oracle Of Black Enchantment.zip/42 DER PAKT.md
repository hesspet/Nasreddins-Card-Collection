# 42 DER PAKT
Die Frau und der Teufel treffen sich allein im Wald, um 
ihren finsteren Pakt zu besiegeln. Ihr Handschlag ist 
bindend, und die heute Nacht getroffene Vereinbarung 
wird bis ans Ende der Zeit bestehen.
## Dunkle Bedeutung:
Ein dunkler Handel. Verräterische Zusammenarbeit. Eine 
unauflösbare Verpflichtung, die man eines Tages bereuen 
könnte.
## Helle Bedeutung:
Gegenseitiges Verständnis. Ein Waffenstillstand. Eine 
vorteilhafte Verbindung. Hervorragende Bedingungen.

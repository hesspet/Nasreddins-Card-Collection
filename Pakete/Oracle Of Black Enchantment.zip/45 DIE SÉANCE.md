# 45 DIE SÉANCE

Geleitet von einem spirituellen Medium, fassen sich eine 
Gruppe Trauernder an den Händen, um mit den Toten zu 
kommunizieren. Während sie die Augen schließen, um sich zu 
konzentrieren, bemerken sie nicht die geisterhafte Hand, die in 
ihren Kreis greift.
## Dunkle Bedeutung:
Jemand oder etwas versucht möglicherweise, Kontakt mit dir 
aufzunehmen. Geistige Einmischung. Ein Portal öffnen, das 
besser geschlossen bliebe.
## Helle Bedeutung:
Kommunikation mit einem entfernten Freund oder geliebten 
Menschen. Energien für einen höheren Zweck bündeln. 
Aufgeschlossen und bereit sein, etwas Unheimliches zu 
empfangen. 
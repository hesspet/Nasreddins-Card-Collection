# 04 ENTFÜHRUNG

Black Mary flieht, nachdem sie einem unschuldigen Kind 
sein liebevolles Zuhause geraubt hat. Ein einfacher Pfad 
führt direkt zu ihrem verfallenen Haus im Wald, wo sie 
versuchen wird, das Kind alleine großzuziehen.

## Dunkle Bedeutung:
Verlust. Gestohlenes Eigentum. Raub. Etwas oder jemand 
wurde dir zu früh genommen.

## Helle Bedeutung:
Ein leicht lösbares Verbrechen oder Rätsel. Folge den 
Hinweisen bis zu ihrer logischen Schlussfolgerung.
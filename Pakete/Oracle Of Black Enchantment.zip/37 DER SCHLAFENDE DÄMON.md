# 37 DER SCHLAFENDE DÄMON

Nach einem langen Tag, an dem er seine Zauber 
perfektioniert hat, legt der müde Dämon den Kopf auf 
den Arbeitstisch und schläft zufrieden ein.
## Dunkle Bedeutung:
Eine Pause machen, obwohl man arbeiten sollte. Faulheit. 
Aufschieben. Die eigene Arbeit nicht ernst nehmen.
## Helle Bedeutung:
Sich erfrischen, bevor man es erneut versucht. 
Körperliche oder geistige Erholung. Wohlverdiente Ruhe 
nach einer produktiven Phase.
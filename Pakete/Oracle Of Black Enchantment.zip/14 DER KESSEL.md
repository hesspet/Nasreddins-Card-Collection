# 14 DER KESSEL

Im Licht eines aufgeladenen Mondes mischen drei 
Hexen blutige Zutaten für ihren abscheulichen Trank. 
## Dunkle Bedeutung:
Eine schlechte Mischung. Böse Taten oder Pläne fügen 
sich zusammen.
## Helle Bedeutung:
Ein großes Problem auflösen und zerschlagen. Ein paar 
schlechte Dinge nehmen und daraus etwas Positives 
machen.
# 13 DIE SCHWARZE KATZE

Eine wilde schwarze Katze spielt mit ihrer jüngsten Beute. 
Schon bald wird sie weiterziehen und ihre tödlichen Krallen 
in ein neues Opfer schlagen.

## Dunkle Bedeutung:
Pech. Ein Omen, vor dem man sich hüten sollte. Ein 
heftiges Problem, das sich nicht leicht abtun lässt. Angst 
und Aberglaube.

## Helle Bedeutung:
Die Kontrolle über entmachtende Überzeugungen 
übernehmen. Sich entscheiden, das eigene Schicksal selbst 
zu gestalten, statt es dem Zufall zu überlassen.
# 20 DAS DÄMONENSCHIFF

Ein Segelschiff voller Dämonen reitet auf den Wellen und 
steuert auf eine ahnungslose Stadt am Horizont zu. Einer 
der Dämonen wirft eine Leine ins Meer und fängt eine 
hilflose Meerjungfrau.
## Dunkle Bedeutung:
Unheil ist unterwegs! Eindringlinge oder ungebetene 
Gäste. Störenfriede.
## Helle Bedeutung:
Kontakt mit fremden Ideen. Neue Menschengruppen 
könnten in dein Leben treten.
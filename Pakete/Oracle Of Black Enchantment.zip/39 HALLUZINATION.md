# 39 HALLUZINATION
Zwei besorgte Mönche führen einen verwirrten jungen 
Mann aus dem Kloster, unfähig, den Dämon zu sehen, 
der sie aus dem Raum heraus verspottet. Vielleicht ist 
der Mann gar nicht verrückt, denn seine Augen lassen 
sich nicht von der Unsichtbarkeit des Dämons täuschen. 
## Dunkle Bedeutung:
Nicht ernst genommen werden. Frustration. Sozialer 
Druck zur Anpassung.
## Helle Bedeutung:
Erkennen, was andere nicht sehen wollen. Sich gegen 
Dogmen oder die herrschende Macht stellen auf der 
Suche nach der Wahrheit.

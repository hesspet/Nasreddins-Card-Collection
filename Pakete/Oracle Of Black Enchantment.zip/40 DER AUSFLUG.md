# 40 DER AUSFLUG
Ein teuflisches Quartett spaziert durch die Landschaft, 
doch einige genossen den Tag mehr als andere. 
## Dunkle Bedeutung:
Feindseliges Verhalten. Ein Tyrann. Ein Spaßvogel. 
Sich auf Kosten anderer profilieren. Versuchen, 
Eindruck zu machen.
## Helle Bedeutung:
Das Beste aus einer schmerzhaften Situation machen. 
Sinn für Humor haben. Flirt.

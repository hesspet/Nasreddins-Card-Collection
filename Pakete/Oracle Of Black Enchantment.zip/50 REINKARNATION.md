# 50 REINKARNATION

Der unsterbliche Geist wandert durch die Zeitalter und bewohnt 
dabei einen Körper nach dem anderen. Eine Seele; viele Leben. 
## Dunkle Bedeutung:
Von vorne anfangen müssen. In einem endlosen Kreislauf 
gefangen sein, gegen den eigenen Willen und außerhalb der 
eigenen Kontrolle. Wiederholung. Die gleichen Fehler erneut 
begehen.
## Helle Bedeutung:
Eine Chance für einen Neuanfang. Eine fortlaufende Abfolge 
von Ereignissen. Eine unendliche Idee, die Generationen 
überdauert. Streben nach Perfektion. Aus vergangenen Fehlern 
lernen.
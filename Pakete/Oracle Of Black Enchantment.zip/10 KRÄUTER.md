# 10 KRÄUTER

Dargestellt sind drei seltene und magische Kräuter, die die 
botanischen Quellen für den Trank der Hexe darstellen. 
Mit ihnen kann sie je nach Bedarf entweder ein Elixier 
oder ein Gift brauen.
## Dunkle Bedeutung:
Gefährliche oder geheime Zutaten. Eine giftige 
Kombination. Eine unlösbare Gleichung.
## Helle Bedeutung:
Ein Heilmittel. Eine neue Lösung, erschaffen durch das 
Kombinieren verschiedener Elemente..
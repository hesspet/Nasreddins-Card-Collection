# 17  DER STREIT

Zwei Matronen kämpfen darum, ein Kinderskelett an sich zu 
reißen. Wenn sie nicht vorsichtig sind, werden sie die Kreatur 
vermutlich auseinanderreißen und mit nichts dastehen.
## Dunkle Bedeutung:
Ein Kampf gegen jemanden, dessen Kräfte den eigenen 
ebenbürtig sind. Patt. Konflikt. Eine Sackgasse. Begehren, was 
jemand anderes bereits besitzt.
## Helle Bedeutung:
Seine Rechte wahren, koste es, was es wolle. Es könnte an der 
Zeit sein, ein unparteiisches Urteil oder eine neutrale Meinung 
einzuholen.
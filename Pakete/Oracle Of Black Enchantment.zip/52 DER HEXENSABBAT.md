# 52 DER HEXENSABBAT

Tief im Herzen des Waldes feiern die Hexen ihren Sabbat 
unter einem hypnotischen Mond. Die Hexenkönigin 
erhebt die Arme, um die Dunkelheit heraufzubeschwören, 
während ihr Zirkel sich verschiedensten verbotenen 
Genüssen hingibt.
## Dunkle Bedeutung:
Gefährliche oder zügellose Rituale. Ausschweifung. Alle 
Hemmungen fallen lassen. Wildes Gruppenverhalten. 
## Helle Bedeutung:
Feier innerhalb einer Gemeinschaft. Wiedervereinigung. 
Ein Höhepunkt oder krönender Erfolg.
# 09 DIE KRANKE HEXE

Eine von Krankheit und Verfall gezeichnete Hexe erbricht 
sich in einen goldenen Kelch. Zwei abscheuliche 
Kreaturen stehen an ihrer Seite; die eine bietet Hilfe an, 
während die andere sich verwirrt kratzt.
## Dunkle Bedeutung:
Krankheit. Gebrechen. Schlechte Folgen körperlicher 
Vernachlässigung oder schlechter Gewohnheiten.
## Helle Bedeutung:
Sich von Giften befreien. Reinigung von Körper, Seele und 
Geist. Eine Reinigung.
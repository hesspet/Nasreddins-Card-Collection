# 19 DER VORBOTE

Der Vorbote des Todes kehrt zu seinem Meister zurück, 
nachdem er Zerstörung über die Stadt gebracht hat.
## Dunkle Bedeutung:
Verderben. Chaos. Ein dunkler Plan ist erfüllt.
## Helle Bedeutung:
Die Rückkehr eines geliebten Menschen nach einer Prüfung. 
Die sichere Wiedererlangung von etwas Verlorenem.
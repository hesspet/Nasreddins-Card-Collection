# 30 DER GEIGER

Der Geiger spielt eine hypnotisierende Melodie für eine 
Gruppe verzauberter Mädchen. Die dunklen Noten 
verwandeln sich in fliegende Dämonen, die die Mädchen 
in einen unauflösbaren Bann ziehen.
## Dunkle Bedeutung:
Verführung. Dunkler Charme. Mit den Gefühlen anderer 
spielen. Massen-Gehirnwäsche. Propaganda.
## Helle Bedeutung:
Angenehme Ablenkung. Bewunderung. Eine bezaubernde 
Fähigkeit.
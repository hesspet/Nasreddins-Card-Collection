# 16 DIE HINRICHTUNG

Eine berüchtigte Bande von Übeltätern baumelt am Galgen. 
Ein Wächter stößt sein Schwert in den Bauch eines der 
Verurteilten, um sicherzustellen, dass die Strafe vollstreckt 
wurde.
## Dunkle Bedeutung:
Schwere Konsequenzen. Mitschuld durch Verbindung. Zeit, 
einen hohen Preis für begangene Verbrechen zu zahlen. Eine 
harte Strafe.
## Helle Bedeutung:
Gerechtigkeit siegt. Die Genugtuung, endlich mitanzusehen, 
wie diejenigen, die einem geschadet haben, bekommen, was sie 
verdienen.
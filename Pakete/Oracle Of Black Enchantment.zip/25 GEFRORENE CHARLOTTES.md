# 25 GEFRORENE CHARLOTTES

Ein kleines Mädchen spielt fröhlich in ihrem Zimmer mit einer 
Sammlung von Figuren. Eine schwarze Hand streckt sich durch 
das Fenster und bietet ihr eine neue Ergänzung für ihre 
Sammlung an.
## Dunkle Bedeutung:
Böse Angebote. Bestechung. Sünde annehmen. Materielle 
Versuchung. Unerwünschte Verpflichtungen.
## Helle Bedeutung:
Annahme. Ein Geschenk. Ein Zeichen von Freundschaft oder 
Frieden.
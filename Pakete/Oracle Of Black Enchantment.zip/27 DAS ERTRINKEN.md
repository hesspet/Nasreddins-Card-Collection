# 27 DAS ERTRINKEN

Ein Sturm kann den Himmel überziehen, während Regen das 
Land überflutet und eine Sintflut verursacht, die sowohl Heilige 
als auch Sünder ertränkt.
## Dunkle Bedeutung:
Gefühle tiefer emotionaler Überforderung. Nicht mithalten 
können. Hilflosigkeit. Eine zutiefst entmutigende Situation. 
## Helle Bedeutung:
Reinigung von Geist und Emotionen. Etwas Altes wegspülen, 
um neu beginnen zu können.
# 23 DAS URTEIL

Eine Frau steht an einen Pfahl gebunden; vom Richter 
und seinen Helfern der Hexerei beschuldigt. Einer der 
Schergen schwingt eine Fackel und bereitet sich darauf 
vor, das Holz zu entzünden und ein loderndes Feuer zu 
entfachen.
## Dunkle Bedeutung:
Schwere Konsequenzen für das eigene Handeln. Ein Tag 
der Abrechnung. Zu Unrecht eines Vergehens 
beschuldigt werden. Indizienbeweise.
## Helle Bedeutung:
Gerechtigkeit. Durchsetzung des Gesetzes. Beseitigung 
eines Problems.
# 06 EINGEWICKELTE HEXEN

Ein bösartiger Dämon lacht vor Freude, während er zwei 
junge Mädchen in unausweichliche Fesseln hüllt. Der 
Mond beobachtet die Szene von oben und deutet an, dass 
die Fesseln nur in den Köpfen der Mädchen existieren. 

## Dunkle Bedeutung:
Gedankenkontrolle. Gehirnwäsche. Propaganda. 
Begrenzende Überzeugungen. Knechtschaft. Ein 
Gefangener oder Geisel. Sich wie in Trance fühlen. 
Verwirrung.

## Helle Bedeutung:
Die Gabe der Überzeugung. Andere dazu bringen, deinen 
Überzeugungen zu folgen. Ein geschickter Redner in einer 
schwierigen Situation..
# 24 RACHE

Eine Hexe, die wegen ihrer angeblichen Verbrechen auf 
dem Scheiterhaufen verbrannt wurde, kehrt in feuriger 
Wut zurück und sucht Rache an ihren verängstigten 
Verfolgern.
## Dunkle Bedeutung:
Ein plötzlicher Ausbruch von etwas, das einst als gelöst 
galt. Wiederkehrende Probleme. Ein ernstes Problem, das 
sich nicht vertreiben oder beseitigen lässt.
## Helle Bedeutung:
Rache. Stärker zurückkommen. Diejenigen, die einst an 
dir zweifelten, könnten nun auf der Flucht sein!
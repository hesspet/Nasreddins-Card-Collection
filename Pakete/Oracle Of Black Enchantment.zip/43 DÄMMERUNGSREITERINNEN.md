# 43 DÄMMERUNGSREITERINNEN
Die maskierten Hexen reiten schnell durch die Nacht. In 
großer Vorfreude auf das, was kommt, fliegen sie über den 
Mond auf dem Weg zum Sabbat.
## Dunkle Bedeutung:
Achtung! Feinde versammeln sich! Die Bosheit nimmt zu. 
## Helle Bedeutung:
Ein Ausflug. Sich mit Gleichgesinnten zu einem gemeinsamen 
Ziel zusammenschließen.

# 47 GLAMOUR

Luzifer, der König der Täuschung, hält einem verwesten Skelett 
einen Spiegel vor, in dem sie eine Illusion ihrer selbst in 
besseren Tagen sieht.

## Dunkle Bedeutung:
Täuschung. Die Dinge nicht so sehen, wie sie wirklich sind. 
Selbstverleugnung. In einer falschen Realität leben. Verzerrte 
Wahrnehmung.

## Helle Bedeutung:
Die Dinge besser sehen, als sie wirklich sind. Vision haben. 
Kann den Kampf darstellen, das beste Selbst zu erreichen.
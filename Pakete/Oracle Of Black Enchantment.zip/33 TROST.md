# 33 TROST

Die Hexe tröstet ein junges Mädchen und versucht, ihr das 
Gefühl zu geben, trotz ihrer offensichtlichen Makel schön 
zu sein. Währenddessen berät ein Trio hochmütiger 
Frauen darüber, wie sie das entstellte Mädchen aus ihrer 
Clique fernhalten können.
## Dunkle Bedeutung:
Ablehnung. Ausgrenzung aus der Gruppe. Geringes 
Selbstwertgefühl. Sich unwürdig fühlen. Mangel an 
Fähigkeiten.
## Helle Bedeutung:
Die eigene Schönheit erkennen. Anders sein und dies als 
besonderes Geschenk annehmen. Selbstwertgefühl. Einen 
echten Freund in schwierigen Zeiten haben.

# 48 DIE FLIEGENDE KÖNIGIN

Die fliegende Königin gleitet über dunkle Wellen auf der Suche 
nach einem besseren Leben und lässt die Dunkelheit ihrer 
Vergangenheit hinter sich.
## Dunkle Bedeutung:
Die Unfähigkeit, der eigenen Situation zu entkommen. Angst, 
sich auf Neues einzulassen. Rückzug.
## Helle Bedeutung:
Mut zur Veränderung. Vorwärtsdrang. Eine 
wachstumsorientierte Denkweise.
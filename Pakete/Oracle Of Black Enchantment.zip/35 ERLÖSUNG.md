# 35 ERLÖSUNG

Die Gebete der fallenden Frau wurden erhört! Drei 
geflügelte Seelen stürzen sich aus den Sternen herab und 
retten sie, bringen sie zurück an die Spitze des Turms, 
wo sie sicher und wohlbehalten ankommt.
## Dunkle Bedeutung:
Etwas retten, das besser dem Tod überlassen worden 
wäre. Jemandem Ansehen verleihen, der es nicht 
verdient. Eine fehlgeleitete Idee aufwerten.
## Helle Bedeutung:
Erlösung. Eine Rettung. Göttliches Eingreifen. Ein 
starkes Unterstützungssystem haben.
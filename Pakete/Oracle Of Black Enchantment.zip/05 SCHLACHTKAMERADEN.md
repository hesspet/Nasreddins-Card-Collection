# 05 SCHLACHTKAMERADEN

Ein Trio skelettierter Kinder hält sich an den Händen und 
tanzt gemeinsam, ohne sich ihrer morbiden Lage bewusst 
zu sein oder sich darum zu kümmern.

## Dunkle Bedeutung:
Ein bevorstehendes Problem ignorieren. Es versäumen, 
sich um eine ernste Situation zu kümmern. Törichte 
Naivität.
## Helle Bedeutung:
Sich nicht über Dinge aufregen, die man nicht 
kontrollieren kann. Unbeschwert im Moment leben. Alle 
Sorgen auf morgen verschieben.
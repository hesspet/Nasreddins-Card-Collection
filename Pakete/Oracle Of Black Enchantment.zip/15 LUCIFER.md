# 15 LUCIFER

Der König der Finsternis hockt auf seinem feurigen Hügel, 
beschwört die Mächte des Bösen und bringt Verdammnis 
über alle Menschen.
## Dunkle Bedeutung:
Ungezügeltes Böses und Boshaftigkeit. Unterdrückung. 
Höchste Dunkelheit. Ein totalitärer Anführer. Eine äußerst 
sadistische Person. Knechtschaft.
## Helle Bedeutung:
Die Fähigkeit, das Böse als das zu erkennen, was es 
wirklich ist. Ein würdiger Gegner, dem man sich stellen 
muss, um frei zu sein.
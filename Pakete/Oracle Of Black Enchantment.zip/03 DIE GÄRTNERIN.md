# 03 DIE GÄRTNERIN

Eine Haushälterin, müde von den lästigen Unkräutern, die 
wild in ihrem Garten wuchern, macht sich daran, die 
Pflanzen mit einem schnellen Schnitt ihrer Gartenschere 
zu köpfen.

## Dunkle Bedeutung:
Der Tod eigener Ideen. Jemand macht dich klein. Eine 
kritische oder destruktive Person.

## Helle Bedeutung:
Probleme ein für alle Mal beseitigen! Persönliche 
Verantwortung übernehmen. Negativität eliminieren.
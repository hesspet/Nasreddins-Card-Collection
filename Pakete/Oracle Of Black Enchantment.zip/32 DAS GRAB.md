# 32 DAS GRAB

Eine verweste Leiche liegt in ihrem Grab und sehnt sich 
danach, wieder die Sonne zu spüren und sich den 
fröhlichen Tänzern oben anzuschließen.
## Dunkle Bedeutung:
Tod. Gefangenschaft. Sich eingesperrt oder isoliert 
fühlen. Sich nach etwas sehnen, das einmal war, aber nie 
wieder sein kann.
## Helle Bedeutung:
Winterschlaf. Sich Zeit nehmen, um neue Energie zu 
schöpfen. Sich freiwillig in einen Kokon zurückziehen,
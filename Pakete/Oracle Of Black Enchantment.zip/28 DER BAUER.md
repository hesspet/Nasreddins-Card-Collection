# 28 DER BAUER

Der zähe Bauer pflügt sein Feld bei 
Sonnenschein und Regen. Obwohl die Elemente alles 
bieten, was er für den Erfolg braucht, verflucht er sie leise 
vor sich hin.
## Dunkle Bedeutung:
Eine undankbare Person. Mangel an Wertschätzung. 
Ausbeutung. Den eigenen Beruf hassen.
## Helle Bedeutung:
Harte Arbeit. Zeit, Dankbarkeit zu üben. Tun, was nötig 
ist, auch wenn einem der Prozess nicht gefällt.
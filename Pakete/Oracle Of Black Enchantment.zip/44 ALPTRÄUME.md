# 44 DÄMMERUNGSREITERINNEN
Zwei Jungen fliehen auf einem schwarzen Ross, verfolgt von 
schrecklichen geflügelten Totenschädeln. Während der vordere 
Reiter von den Kreaturen verängstigt ist, dreht sich der zweite 
Junge um, um dem Bösen seine wahren Gefühle zu zeigen. 

## Dunkle Bedeutung:
Schreckliche Träume. Tiefe Angst. Die Notwendigkeit, vor 
etwas Furchtbarem schnell zu fliehen. Ungezähmte Sorgen. 
## Helle Bedeutung:
Angst mit Gelassenheit begegnen. Immer einen Schritt vor der 
Katastrophe bleiben. Die Oberhand über Sorgen oder Angst 
gewinnen.

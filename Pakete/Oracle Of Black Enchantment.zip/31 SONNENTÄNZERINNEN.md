# 31 SONNENTÄNZERINNEN

Eine fröhliche Gruppe von Jungfrauen tollt während der 
Sommersonnenwende durch die Wiese. Die Mädchen 
sind unbeschwert und denken kaum an das 
unvermeidliche Herannahen des Winters.
## Dunkle Bedeutung:
Vergangene gute Zeiten. Sehnsucht nach besseren 
Tagen. Seliges Unwissen.
## Helle Bedeutung:
Eine Zeit ohne große Sorgen. Glück mit Freunden. 
Schöne Tage oder Erinnerungen. Im Moment leben.
# 22 VERLASSENHEIT

Ein missmutiges Mädchen kehrt der Zukunft und ihren 
Möglichkeiten den Rücken. Eine Vogelschar, die nichts mit 
der Traurigkeit zu tun haben will, flieht vor ihr und macht 
sich auf zu besseren Aussichten.
## Dunkle Bedeutung:
Verlassenheit. Isolation oder Rückzug. Selbstmitleid. 
Depression.
## Helle Bedeutung:
Eine trostlose Beziehung oder Situation hinter sich lassen. 
Auf der Suche nach einem besseren Leben.
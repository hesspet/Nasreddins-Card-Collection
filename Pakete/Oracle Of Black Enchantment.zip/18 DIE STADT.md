# 18 DIE STADT

Eine glorreiche, ummauerte Stadt glänzt wie ein Juwel auf 
dem Hügel, ein Zufluchtsort – doch dunkle Wolken ziehen aus 
der Ferne heran, Vorboten des Schreckens, der noch kommen 
wird.
## Dunkle Bedeutung:
Das gute Leben steht auf der Kippe! Schwierigkeiten drohen, 
die Schutzmauern zu durchbrechen, von denen du dachtest, sie 
würden dich sicher halten. Ein drohender Zusammenbruch all 
dessen, wofür du gearbeitet hast.
## Helle Bedeutung:
Ein starkes und dauerhaftes Vermächtnis, geschaffen, um die 
Zeiten zu überdauern. Die höchste Errungenschaft einer 
Gesellschaft. Ein großes Projekt, das zur Vollendung kommt.
7